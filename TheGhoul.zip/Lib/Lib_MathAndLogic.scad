/*
  <GHOUL/Lib/Lib_MathAndLogic.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

include<MathAndLogic/AndIsFalse.scad>
include<MathAndLogic/AndIsTrue.scad>
include<MathAndLogic/ATan2.scad>
include<MathAndLogic/BinomialCoefficient.scad>
include<MathAndLogic/Clip.scad>
include<MathAndLogic/ColorHexToTuple.scad>
include<MathAndLogic/ColorTupleToHex.scad>
include<MathAndLogic/DayOfTheWeek.scad>
include<MathAndLogic/Decimals.scad>
include<MathAndLogic/DecToHex.scad>
include<MathAndLogic/Deg.scad>
include<MathAndLogic/Factorial.scad>
include<MathAndLogic/GreatestCommonDivisor.scad>
include<MathAndLogic/HexToDec.scad>
include<MathAndLogic/InchFraction.scad>
include<MathAndLogic/InlineVertex.scad>
include<MathAndLogic/Intermediate.scad>
include<MathAndLogic/Interpolate.scad>
include<MathAndLogic/IsLogic.scad> // Contains several Is...() functions.
include<MathAndLogic/LeastCommonMultiple.scad>
include<MathAndLogic/Map.scad>
include<MathAndLogic/MCeil.scad>
include<MathAndLogic/MFloor.scad>
include<MathAndLogic/Mod.scad>
include<MathAndLogic/MostSignificant.scad>
include<MathAndLogic/MRound.scad>
include<MathAndLogic/NDecimal.scad>
include<MathAndLogic/NearestEven.scad>
include<MathAndLogic/NearestOdd.scad>
include<MathAndLogic/OffLimits.scad>
include<MathAndLogic/OrderOfMagnitude.scad>
include<MathAndLogic/OrIsFalse.scad>
include<MathAndLogic/OrIsTrue.scad>
include<MathAndLogic/PowAlias.scad> // Contains several pow() aliases.
include<MathAndLogic/Rad.scad>
include<MathAndLogic/Rnd.scad>
include<MathAndLogic/Sequence.scad>
include<MathAndLogic/Sign.scad>
include<MathAndLogic/UndefFallback.scad>
include<MathAndLogic/ZeroThought.scad>
include<MathAndLogic/ZeroFallback.scad>
