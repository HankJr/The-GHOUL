/*
  This enables us to use "if(AnFrac([2,2,8,8])>0.5)" constructs and so on.
  For more info, see Animate.scad in this directory.
*/
function AnFrac(AnimVector,Frequency=1)=
    /* Return the animation fraction value with *Frequency* forced 1, also see AnimationFxFraction.scad. */
    AnFxFr(AnimVector,1)
;

