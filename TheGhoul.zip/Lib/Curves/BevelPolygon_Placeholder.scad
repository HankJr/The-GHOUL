/*
  complex polygon
  * walk first path, move points left
  * walk subsequent paths, move points right

  * move points on line intersecting angle between previous and next connecting line
  * find nearest point in move direction (check points on affected side of line perpendicular to movement line through the point)

  *
*/
/* TODO: LOTS, VERY MUCH UNFINISHED. */
function OffsetPolygon(PolyOld,Bevel)=
    let(
        Bar=undef,
        Shape=PolyOld[0],
        _len=Len(Shape),
        NewShape=[
            for(Idex=[0:_len])
            BisectorAngle(
                Shape[Map(Idex-1,0,_len)],
                Shape[Map(Idex,0,_len)],
                Shape[Map(Idex+1,0,_len)]
            )
        ]
    )
    Bar
;

