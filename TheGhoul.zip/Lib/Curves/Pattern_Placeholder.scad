/*
  Take any curve, and display as dotted, dashed, or dash-dot pattern.
*/
