function CircleAngles(Radius)=
    let(
        Steps=Segments(Radius)
    )
    /* Note: the last Step is omitted (360==0). */
    [ for(Step=[0:Steps-1]) Step/Steps*360 ]
;

