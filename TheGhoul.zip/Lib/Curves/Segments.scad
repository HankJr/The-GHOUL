/*
  Optimal number of segments for a circle or circular arc, based on $fa, $fs, $fn, in a method SIMILAR to OpenSCAD's.

  There will NEVER be fewer segments than 4.
  With this caveat in mind:
  *If $fn is NOT 0, there will be $fn segments.
    Otherwise,
    *If *Radius* is undefined, the segment NUMBER will be 360/$fa.
    Otherwise,
      * The segment size will be at least $fs, and the segment NUMBER will be no more than 360/$fa, unless $ff is NOT 0, in which case the segment size will be no larger than $ff, regardless of the segment number.

  To ensure vertices on the cardinal directions:
  $fa should be a factor of 90 and no less than 0.1 (OpenSCAD will complain); default is 12, which is no factor, so The GHOUL uses 6, which yields 60 segments on a circle, like the minutes on a clock; how nice is that?
  $fn should be a multiple of 4 but (preferably) no more than 128 (or your CPU may not love you); default is 0 (which hands control to $fa and $fs), $fn<>0 renders $fa and $fs impotent.
  $fs should be a (small) multiple of your printer's resolution and no less than 0.1 (OpenSCAD will complain); The GHOUL's default is 0.4.
  $ff should not be too small, for the sake of your CPU, default is 0 (i.e. 'off'); make it as large as you can 'stand it'.
*/
function Segments(Radius)=
    $fn>0       // $fn overrides EVERYTHING.
    ?   $fn
    :    MCeil(
            max(4,  // The GHOUL's hard minimum of 4 per full circle.
                    // (Seriously, is a square a circle? I feel this
                    // should perhaps be at least 8, even 12, certainly
                    // not OpenSCAD's 3 or 5...)
                Radius==undef
                    // Without a dimensional reference, all we have is angles.
                ?   360/$fa
                        // $ff is the largest acceptable 'flat' side, and
                        // it overrides $fs and $fa.
                :   max($ff==0?0:Radius*2*PI/$ff,
                        min(
                            // The number of $fs size sections for this radius.
                            Radius*2*PI/$fs
                            // The number of $fa angles per full circle.
                            ,360/$fa
                        )
                    )
        )
        ,4      // >>> Full circles MUST** be a 4-fold so that there
                // >>> are vertices on the cardinal directions.
                // ** That is to say, according to The GHOUL, i.e., me.
        )
;

/*
  OpenSCAD native algorithm; see $fa, $fn, $fs entry in the manual, OpenSCAD uses the term 'fragments' so I've done the same.
*/
function Fragments(Radius=1)=
    $fn>0.0?max($fn,3):ceil(max(min(Radius*2*PI/$fs,360/$fa),5))
;

