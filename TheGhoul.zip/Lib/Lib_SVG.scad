/*

  <GHOUL/Lib/Lib_SVG.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.

*/

include<SVG/SVG.scad>
include<SVG/SVG_Shape.scad>
include<SVG/SVG_Glyph.scad>

// Not in Geany config files, because they ARE NOT user functions:
include<SVG/SVGCommandPositions.scad>
include<SVG/SVGNextCommand.scad>
include<SVG/SVGParameterPositions.scad>
include<SVG/SVGParsePath.scad>
include<SVG/SVGPathMovePositions.scad>
include<SVG/SVG_A.scad>
include<SVG/SVG_B.scad> // Todo: placeholder for chamfer
include<SVG/SVG_C.scad>
include<SVG/SVG_F.scad> // Todo: placeholder for fillet
include<SVG/SVG_H.scad>
include<SVG/SVG_L.scad>
include<SVG/SVG_M.scad>
include<SVG/SVG_Q.scad>
include<SVG/SVG_S.scad>
include<SVG/SVG_T.scad>
include<SVG/SVG_V.scad>

