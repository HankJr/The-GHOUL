/*

  <GHOUL/Lib/Lib_Strings.scad>

  Hank J. van Leuvensteijn Jr. 2019
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.

*/

include<Strings/Alphabetical.scad>
include<Strings/AsciiMapString.scad>
include<Strings/FillString.scad>
include<Strings/IsHex.scad>
include<Strings/IsString.scad>
include<Strings/IsUniCode.scad>
include<Strings/LeftString.scad>
include<Strings/LowerCase.scad>
include<Strings/MapString.scad>
include<Strings/PadString.scad>
include<Strings/Prefix.scad>
include<Strings/ReplaceCharacters.scad>
include<Strings/RightString.scad>
include<Strings/ScrubCharacters.scad>
include<Strings/ScrubRepeated.scad>
include<Strings/SetDecimals.scad>
include<Strings/StringToTuple.scad>
include<Strings/StringToDecimal.scad>
include<Strings/SubString.scad>
include<Strings/TupleToString.scad>
include<Strings/UniCodeMapString.scad>
include<Strings/UpperCase.scad>

