/*

  <GHOUL/Lib/Lib_Tuples.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.

*/

include<Tuples/CropTuple.scad>
include<Tuples/FillTuple.scad>
include<Tuples/Interval.scad>
include<Tuples/LeftTuple.scad>
include<Tuples/PadTuple.scad>
include<Tuples/RangeToTuple.scad>
include<Tuples/RemoveElement.scad>
include<Tuples/ReplaceUndef.scad>
include<Tuples/ReverseTuple.scad>
include<Tuples/RightTuple.scad>
include<Tuples/SetTupleElement.scad>
include<Tuples/SubTuple.scad>

include<Tuples/IsInRange.scad>
