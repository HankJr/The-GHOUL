/*
  <GHOUL/Lib/Lib_Curves.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

/* Contains the Bézier curves introductory notes, as well as back-end routines. Yes. Of course it's chock-a with comments; this is The GHOUL! */
include<Bezier/Bezier.scad>

include<Bezier/BezierFractionX.scad>
include<Bezier/BezierFractionY.scad>
include<Bezier/BezierCurve.scad>
include<Bezier/BezierCurveLength.scad>

/* Also contains CBezierVertex(), QBezierVertex() and some other routines. */
include<Bezier/BezierVertex.scad>

include<Bezier/BezierShape.scad>
include<Bezier/BezierSolid.scad>

include<Bezier/DeCasteljau.scad>

include<Bezier/ShowDeCasteljau.scad>
include<Bezier/ShowTPA.scad>
