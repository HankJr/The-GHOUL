/*
  <GHOUL/Lib/Lib_Arrays.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

/*
  TODO ArrayPush()ArrayPop()ArrayShift()ArrayUnShift()
*/

// Array manipulators
include<Arrays/ArrayAdd.scad>
include<Arrays/ArrayDomain.scad>
include<Arrays/ArrayProduct.scad>
include<Arrays/ArraySelect.scad>
include<Arrays/ArrayShift.scad>
include<Arrays/ArraySum.scad>
include<Arrays/CropArray.scad>
include<Arrays/Dex.scad>
include<Arrays/Find.scad>
include<Arrays/FindEQ.scad>
include<Arrays/FindGT.scad>
include<Arrays/FindGTE.scad>
include<Arrays/FindLT.scad>
include<Arrays/FindLTE.scad>
include<Arrays/FindNE.scad>
include<Arrays/FlattenArray.scad>
include<Arrays/GetValue.scad>
include<Arrays/Intersection.scad>
include<Arrays/IsInArray.scad>
include<Arrays/Last.scad>
include<Arrays/LeftArray.scad>
include<Arrays/Len.scad>
include<Arrays/Match.scad>
include<Arrays/MoebiusArray.scad>
include<Arrays/PadArray.scad>
include<Arrays/QuickFind.scad>
include<Arrays/QuickSort.scad>
include<Arrays/RemoveDoubles.scad>
include<Arrays/RemoveRepeated.scad>
include<Arrays/RemoveSuccessive.scad>
include<Arrays/RemoveUndefs.scad>
include<Arrays/ReverseArray.scad>
include<Arrays/RightArray.scad>
include<Arrays/RoundArray.scad>
include<Arrays/ScaleArray.scad>
include<Arrays/SetArrayElement.scad>
include<Arrays/SmashArray.scad>
include<Arrays/Stepped.scad>
include<Arrays/SubArray.scad>
include<Arrays/SumArrays.scad>


