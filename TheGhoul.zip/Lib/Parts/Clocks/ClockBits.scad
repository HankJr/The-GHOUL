module Shaft(OD,ID,UP,DN=0,Kolor=OSG){

    Shaft=ID>0
        ?   Ring(OD,(OD-ID)/2)
        :   Circle(OD/2);

    color(Kolor)
    translate([0,0,-DN])
    linear_extrude(UP+DN)
    polygon(Shaft[0],Shaft[1]);

}

module Bearing(OD=22,ID=8,TH=6,Kolor=BRN){

    Shaft(OD,ID,TH/2,-TH/2,Kolor);

}

module Coupler(OD=16,ID=0,L=4,Kolor=DSG){

    Shaft(OD,ID,L,0,Kolor);

}

