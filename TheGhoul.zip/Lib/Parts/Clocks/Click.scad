module ClockClick(){

}

