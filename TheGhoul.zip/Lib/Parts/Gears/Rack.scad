function Rack(Module,Teeth,Addendum=1,Dedendum=1.25,Shift=0,PressureAngle=20,Allowance=0,Title="",Tip=0.2,Root=0.2,Support=1)=
    let(
        Tooth=RackTooth(Module,Addendum,Dedendum,Shift,PressureAngle,Allowance,Title,Tip,Root),
        Pitch=Pi*Module,
        // Renamed root....??
        Rott=Module*(Shift-Dedendum)
    )
    concat(
        [[Rott-Support,-Pitch/2],[Rott,-Pitch/2]],
        FlattenArray(
            [
                for(A=[0:Teeth-1])
                    ArrayAdd(Tooth,A*[0,Pitch])
            ]
        ),
        [[Rott,Pitch*(Teeth-1/2)],[Rott-Support,Pitch*(Teeth-1/2)]]
    )
;

module Rack(Module,Teeth,Addendum=1,Dedendum=1.25,Shift=0,PressureAngle=20,Allowance=0,Title="",Tip=0.2,Root=0.2,Support=1){

    polygon(Rack(Module,Teeth,Addendum,Dedendum,Shift,PressureAngle,Allowance,Title,Tip,Root,Support));
}
