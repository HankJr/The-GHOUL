// Text that stays in the same location (on the screen). Requires regen.
module ScreenText(String,Location=[0,-5,0],Rotation=[15,25,0],Size=1,Thickness=1,Font="Noto Mono",Spacing=1,SizeCompensation=40,ScreenFactor=40,Correction=[0,0,0]){
    // Compensate for viewport translation and rotation ($vpt and $vpr).
    translate($vpt)
    rotate($vpr)
    // Place on screen, compensated for distance ($vpd).
    translate(Location*$vpd/ScreenFactor)
    // Make the font look good.
    rotate(Rotation)
    translate(Correction)
    // Text size is compensated for $vpd.
    SimpleText(String,Size*$vpd/SizeCompensation,Thickness*$vpd/SizeCompensation,Center=true,Font,Spacing);
}

/*
  text(t, size, font,
     halign, valign, spacing,
     direction, language, script).
*/


// Text that stays in the same location (in the UCS) facing the viewer. Requires regen.
module VPRText(String,Size=1,Font="Noto Mono",Halign="left",Valign="baseline",Spacing=1,Thickness=1,Location=[0,0,0],Rotation=[15,25,0]){
    // I like to move-it, move-it... No? Oh, never mind.
    translate(Location)
    // Compensate for viewport rotation $vpr.
    rotate($vpr)
    // Make the font look good.
    rotate(Rotation)
    linear_extrude(Thickness)
    // Text size is compensated for $vpd.
    text(text=String,size=Size,font=Font,halign=Halign,valign=Valign,spacing=Spacing);
}
