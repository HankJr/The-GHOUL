/*
  Affine translation matrix
*/
function TranslationMatrix(Vector=[0,0,0])=
    [
        [1, 0, 0, Vector.x],
        [0, 1, 0, Vector.y],
        [0, 0, 1, Vector.z],
        [0, 0, 0,        1]
    ]
;
