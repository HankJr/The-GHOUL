/*
    Transpose_M(
     [[11,12,13],
      [21,22,23],
      [31,32,33]])
    =>
     [[11, 21, 31],
      [12, 22, 32],
      [13, 23, 33]]
*/
function MatrixTranspose(Matrix)=
    [
        for(Row=[0:len(Matrix)-1])
            [
                for(Column=[0:len(Matrix[0])-1])
                    Matrix[Column][Row]
            ]
    ]
;
