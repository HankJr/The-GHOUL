/*
  Homogenised 4 x 4 Matrix
*/
function HomogeniseMatrix(Matrix)=
    [   for (i=[0:3])
        [   for (j=[0:3])
            undef==Matrix[i][j]
            ?   i==j
                ?   1
                :   0
            :   Matrix[i][j]
        ]
    ]
;
