/*
  Identity Matrix
*/
function IdentityMatrix(Size=3)=
    [   for (Row=[0:Size-1])
        [   for (Column=[0:Size-1])
            Row == Column
            ?   1
            :   0
        ]
    ]
;
