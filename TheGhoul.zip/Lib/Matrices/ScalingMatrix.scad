/*
    Affine scaling matrix

    Note: Negative scale equals reflection, i.e vector=[-1,1,1] mirrors with
          x-axis as normal vector, i.e., in the X=0 or Y-Z plane.
*/
function ScalingMatrix(Vector=[0,0,0])=
    [
        [Vector.x,        0,        0, 0],
        [       0, Vector.y,        0, 0],
        [       0,        0, Vector.z, 0],
        [       0,        0,        0, 1]
    ]
;
