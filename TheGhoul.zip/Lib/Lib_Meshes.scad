/*
  <GHOUL/Lib/Lib_Meshes.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

include<Meshes/CoverMesh.scad>

// Not in Geany configuration files.
include<Meshes/QuadSpace.scad>
