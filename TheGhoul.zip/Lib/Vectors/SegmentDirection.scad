/*
  Direction of the line segment from Vertex1 to Vertex2.
  Vertices can be 2D or 3D.
  Really just a shortcut to VectorToIncAz (Not a true alias as this takes 2 vertices as input, and VectorToIncAz takes a vector.)
*/
function SegmentDirection(Vertex1,Vertex2)=
    VectorToIncAz(Vertex2-Vertex1)
;
