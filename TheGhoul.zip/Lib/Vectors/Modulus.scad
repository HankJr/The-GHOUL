/*
  Magnitude or length  a.k.a. 'modulus' of a vector.

  | Modulus([1, 2, 3]) => 3.74166

  This is the same as the native function 'norm()'.
*/
function Modulus(Vector) =
    sqrt(Vector*Vector)
;
