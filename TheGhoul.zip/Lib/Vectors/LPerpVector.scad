/*
  Vector 90 degrees left (perpendicular) to projection of the input vector on the plane Z=0.
*/
function LPerpVector(Vector,Length=1)=
    len(Vector)==3
    ?   UnitVector([-Vector.y,Vector.x,0])*Length
    :   UnitVector([-Vector.y,Vector.x])*Length
;
