/*
  Unit vector; has the same direction as the input vector and a length of 1.

  |   UnitVector([1, 2, 3]) =>  [0.267261, 0.534522, 0.801784]
*/
function UnitVector(Vector) =
    Modulus(Vector) > 0
    ?   Vector/Modulus(Vector)
    :   undef
;
