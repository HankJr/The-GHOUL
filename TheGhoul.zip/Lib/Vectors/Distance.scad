// Distance between two points, also modulus when only one point is given.
function Distance(Point1,Point2)=
    let(
        Vector=undef==Point2
        ?   Point1
        :   Point2-Point1
    )
    sqrt(Vector*Vector)
;
