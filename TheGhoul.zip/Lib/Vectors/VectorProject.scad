/*
  Project one vector coordinate onto the remaining dimensions (3D onto plane, 2D onto axis &c), defaults to 3D onto Z=0.
*/
function VectorProject(Vector,Dim=2)=
    [
        for(Idex=[0:Len(Vector)])
            Idex==Dim
            ?   0
            :   Vector[Idex]
    ]
;
