/*
  Vector 90 degrees right (perpendicular) to input vector.
*/
function RPerpVector(Vector,Length=1)=
    len(Vector)==3
    ?   UnitVector([Vector.y,-Vector.x,0])*Length
    :   UnitVector([Vector.y,-Vector.x])*Length
;
