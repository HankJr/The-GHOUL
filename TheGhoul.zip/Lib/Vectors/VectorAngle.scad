/*
  Angle between two vectors.
*/
function VectorAngle(Vector1,Vector2)=
    len(Vector1) != len(Vector2)
    ?   undef
    :   acos(DotProduct(Vector1,Vector2)/(Modulus(Vector1)*Modulus(Vector2)))
;
