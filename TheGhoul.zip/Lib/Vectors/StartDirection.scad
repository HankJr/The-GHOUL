/*
  Direction of the first line segment from VertexList[0] to VertexList[1].
  Vertices can be 2D or 3D.
  Really just a shortcut to VectorToIncAz (Not an alias as this takes a vertex-list (array) as input, and VectorToIncAz takes a vector.)
*/
function StartDirection(VertexList)=
    SegmentDirection(VertexList[0],VertexList[1])
;
