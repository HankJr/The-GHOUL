/*
  Convert homogenous 2D and 3D coordinates to cartesian.

  | ProjectVector([1,2,3,0.1])) => [10, 20, 30]
*/
function ProjectVector(Vector)=
    let(
        Last=Len(Vector)
    )
    [ for(Index=[0:Last-1])
        Vector[Index]/Vector[Last]
    ]
;
