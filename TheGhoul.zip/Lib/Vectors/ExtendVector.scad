/*
  Lengthen (or shorten) a vector by a number of units.
*/
function ExtendVector(Vector,Extension) =
    is_num(Extension)
    ?   Vector*(Modulus(Vector)+Extension)/Modulus(Vector)
    :   Extension.x!=undef
        ?   Vector*(Vector.x+Extension.x)/Vector.x
        :   Extension.y!=undef
            ?   Vector*(Vector.y+Extension.y)/Vector.y
            // logically the only remaining option, but we'll check...
            :   Extension.z!=undef
                ?   Vector*(Vector.z+Extension.z)/Vector.z
                :   undef
;
