/*
  Upgrade cartesian vector (point) to 3D (if needed) and homogenise.

  |   HomogeniseVector([1,2])) => [1, 2, 0, 1]
*/
function HomogeniseVector(Vector) =
    len(Vector) > 3
    ?   undef
    :   concat(PadTuple(Vector),1)
;
