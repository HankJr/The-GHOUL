/*
  Dot product of two vectors.

  |   DotProduct([1, 2, 3], [4, 5, 6]) => 4+10+18=32
*/
function DotProduct(Vector1,Vector2) =
    Vector1*Vector2
;
