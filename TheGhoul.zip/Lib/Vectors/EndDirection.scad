/*
  Direction of the last line segment from VertexList[last-but-one] to VertexList[last].
  Vertices can be 2D or 3D.
  Really just a shortcut to VectorToIncAz (Not an alias as this takes a vertex-list (array) as input, and VectorToIncAz takes a vector.)
*/
function EndDirection(VertexList)=
    let(
        Ldex=Len(VertexList)
    )
    SegmentDirection(VertexList[Ldex-1],VertexList[Ldex])
;
