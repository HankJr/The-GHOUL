/*
    FillTuple(4,12) => [12,12,12,12]
*/
function FillTuple(Length,Value)=
    [ for(i=[0:Length-1])
        Value
    ]
;
