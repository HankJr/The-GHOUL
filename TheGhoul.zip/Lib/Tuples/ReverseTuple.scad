/*
    ReverseTuple([1, 2, 3]) => [3, 2, 1]
    * Alias for ReverseArray()
*/
function ReverseTuple(Tuple)=
    ReverseArray(Tuple)
;
