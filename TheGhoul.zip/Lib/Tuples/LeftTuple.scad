/*
    LeftTuple([0, 1, 2, 3], 2) => [0, 1, 2] (all elements up to Index 2 inclusive)
*/
function LeftTuple(Tuple,End) =
    let(
        _End=Dex(End,Len(Tuple)),
        Foo=Alert(["Index out of range at ",End,", mapped onto ",_End,"."],0,abs(End)>Len(Tuple))
    )
        [
            for(I=[0:_End])
                Tuple[I]
        ]
;
