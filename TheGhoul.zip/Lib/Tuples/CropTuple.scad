/*
  Crop a tuple down to a length. Most commonly used to crop and 'demote' a 3D vector down to a 2D vector, hence the default length of _2_.
*/
function CropTuple(Tuple,Length=2)=
    len(Tuple)<Length
    ?   undef
    :   [for(Index=[0:Length-1])Tuple[Index]]
;
