/* TODO rename 'ExpandRange'?
    RangeTuple([0 : 2 : 6]) => [0, 2, 4, 6]
*/
function RangeToTuple(Range=[])=
    [
        for(Index = Range)
            Index
    ]
;
