/*
  Replaces 'undef' with 'Replacement'
  Can't think why I wrote this...
*/
function ReplaceUndef(StringsTuple,Replacement)=
    [
        for(Element=StringsTuple)
            Element==undef
            ?   Replacement
            :   Element
    ]
;

