/*
    Pad tuple to Length, defaults to length of _3_ to facilitate 2D to 3D 'upgrade'.
*/
function PadTuple(Tuple=[],Length=3,Padding=0)=
    len(Tuple)<Length
    ?   PadTuple(concat(Tuple,Padding),Length,Padding)
    :   Tuple
;
