/*
    SetTupleElement_T([1, 2, 3, 4], 2, 5) => [1, 2, 5, 4]
*/
function SetTupleElement(Tuple,Index,Value)=
    let(
        _Index=Dex(Index,Len(Tuple)),
        Foo=Alert(["Index= ",Index," and out of range, mapped onto ",_Index,"."],0,abs(Index)>Len(Tuple))
    )
    [ for (Jdex = [0 : Len(Tuple)])
        Jdex == _Index
        ?   Value
        :   Tuple[Jdex]
    ]
;
