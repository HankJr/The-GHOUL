/*
    Sub_T([0, 1, 2, 3, 4, 5, 6], 0, 2)   => [0, 1, 2]
    Sub_T([0, 1, 2, 3, 4, 5, 6], 0, -4)  => [0, 1, 2 ,3]
    Sub_T([0, 1, 2, 3, 4, 5, 6], -4, 4)  => [3, 4]
    Sub_T([0, 1, 2, 3, 4, 5, 6], -4, -1) => [3, 4, 5, 6]
    Sub_T([0, 1, 2, 3, 4, 5, 6], 5, -1)  => [5, 6]
*/
function SubTuple(Tuple,Begin=0,End=-1)=
    let(
        _Begin=Dex(Begin,Len(Tuple)),
        Foo=Alert(["Begin= ",Begin," and out of range, mapped onto ",_Begin,"."],0,abs(Begin)>Len(Tuple)),
        _End=Dex(End,Len(Tuple)),
        Bar=Alert(["End= ",End," and out of range, mapped onto ",_End,"."],0,abs(End)>Len(Tuple))
    )
    _End<_Begin
    ?   undef
    :   [ for (Index = [_Begin : _End])
            Tuple[Index]
        ]
;
