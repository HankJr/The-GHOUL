/*
    RightTuple([0, 1, 2, 3], 2) =>    [2, 3] (all elements from Begin 2 inclusive)
*/
function RightTuple(Tuple,Begin)=
    let(
        _Begin=Dex(Begin,Len(Tuple)),
        Foo=Alert(["Begin out of range at ",Begin,", mapped onto ",_Begin,"."],abs(Begin)>Len(Tuple))
    )
    SubTuple(Tuple,_Begin)
;
