/*
  Usage: check if a value exists in a range:
  Rng = [0:2:6];
  IsInRange(Rng,4)      = true
 */
function IsInRange(Value,Range)=
    let(
        Array=RangeToTuple(Range)
    )
    search(Value,Array)[0]!=undef
;
