/*
  Fillet: F/f (Fx,Fy,Nx,Ny)+ Repetitions are unlikely but possible.

  draws radius using cubic Bézier and 0.552 factors for controlpoints

  Fx,Fy fillet corner point
  Nx,Ny next point
*/

