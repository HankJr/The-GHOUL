/*
  Extend: E/e (Length,Nx,Ny)+ Repetitions are unlikely but possible.
*/

