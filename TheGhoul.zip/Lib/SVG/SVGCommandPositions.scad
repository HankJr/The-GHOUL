/*
  find commands in sub-path

  Path, string, subpath from SVG path-string
*/
function SVGCommandPositions(Path)=
    let(
        // turn the path into an array of ascii values
        PathAsciiMapString=AsciiMapString(Path),
        // find command locations within the path and put their indices into an array
        Positions=[
            for(Idex=[0:1:Len(PathAsciiMapString)])
                if(IsInArray(PathAsciiMapString[Idex],SVGPlusAscii))Idex
        ]
    )
    Positions
;

