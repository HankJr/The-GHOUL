/*
    Collections of SVG 'shapes' are kept in this file. You can do it differently, split them up into different files by type or function, whatever blows your hair back. Do as you please.
*/

/*
  Collections of shapes are of this form:
    CollectionName=[
        ["Name","SVG_Path",SVG_Coords,"ID"],
        [...]
    ];

  Name: string, name of the shape or icon
  SVG_Path: string, a valid SVG path-string
  SVG_Coords: Boolean, use SVG coordinates if 'true'

  Some may have elements that are not (yet) used, like the "ID" element in 'FavIcons'.

*/

// COLLECTIONS =================================================================

DemoShapes=[

["MapleLeaf","M 0 0 45 -863 a 95 95 0 0 0 -111 -98 l -859 151 116 -320 a 65 65 0 0 0 -20 -73 l -941 -762 212 -99 a 65 65 0 0 0 34 -79 l -186 -572 542 115 a 65 65 0 0 0 73 -38 l 105 -247 423 454 a 65 65 0 0 0 111 -57 l -204 -1052 327 189 a 65 65 0 0 0 91 -27 l 332 -652 332 652 a 65 65 0 0 0 91 27 l 327 -189 -204 1052 a 65 65 0 0 0 111 57 l 423 -454 105 247 a 65 65 0 0 0 73 38 l 542 -115 -186 572 a 65 65 0 0 0 34 79 l 212 99 -941 762 a 65 65 0 0 0 -20 73 l 116 320 -859 -151 a 95 95 0 0 0 -111 98 l 45 863 z",true]

];

