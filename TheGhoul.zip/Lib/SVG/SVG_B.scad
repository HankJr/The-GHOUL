/*
  Chamfer: B/b (Size,Nx,Ny)+ Repetitions are unlikely but possible.
*/

