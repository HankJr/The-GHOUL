/*
  find sub-paths in path.

  PathString, string, valid SVG path-string
*/
function SVGPathMovePositions(PathString)=
    let(
        PathAsciiMapString=AsciiMapString(PathString), // ascii values of path-string
        SVGMoveAscii=[77,109] // "Mm"
    )
    // return the array with 'M' and 'm' locations
    [
        for(Idex=[0:Len(PathAsciiMapString)])
            if(IsInArray(PathAsciiMapString[Idex],SVGMoveAscii))Idex
    ]
;

