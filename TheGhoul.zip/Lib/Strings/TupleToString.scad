/*
  Takes an array of characters, strings or values (or any combination thereof) and chains them together into a single string.
*/
// Errortrap
function TupleToString(StringsTuple,Separator="")=
    StringsTuple==[]
    ?   ""
    :   _TupleToString(StringsTuple,Separator,Len(StringsTuple))
;
// Recursive helper.
function _TupleToString(StringsTuple,Separator,Index) =
    Index==0
    ?   undef==StringsTuple[Index]?"":StringsTuple[Index]
    :   str(_TupleToString(StringsTuple,Separator,Index-1),Separator,undef==StringsTuple[Index]?"":StringsTuple[Index])
;
