/*
    FillString(2,"8F") => "8F8F"
*/
function FillString(Repetitions,Chars)=
    TupleToString([ for(i=[0:Repetitions-1])
        Chars
    ])
;
