/*
  ScrubCharacters("J","JIM") -> "IM"
*/
function ScrubCharacters(InChars,String)=
    TupleToString(
        [
            for(Char=String)
            /* Anthing not in *InChars* remains unchanged. */
                if(search(Char,InChars)==[])
                   Char
        ]
    )
;
