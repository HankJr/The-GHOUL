/* Useful alias for SVG font UniCode code point ? */
function IsUniCode(String)=
    IsHex(String,4)
;
