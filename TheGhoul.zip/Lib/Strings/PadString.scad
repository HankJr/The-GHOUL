/*
    Pad Length
*/
function PadString(String,Length=3,Padding="")=
    len(String)<Length
    ?   PadString(TupleToString(concat(String,Padding)),Length,Padding)
    :   String
;

function ModString(String="",Modl=5,Padding="")=
    let(
        Length=ceil(len(String)/Modl)*Modl
    )
    len(String)<Length
    ?   PadString(TupleToString(concat(String,Padding)),Length,Padding)
    :   String
;
