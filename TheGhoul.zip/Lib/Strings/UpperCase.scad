/*
  Turns lowercase letters in a string to uppercase. Leaves all non-letter symbols unchanged.
*/
function UpperCase(String)=
    let(
        Characters=TupleToString(concat(UpperCase,LowerCase))
    )
    TupleToString(
        [
            for(Char=String)
                undef==search(Char,Characters)[0]
                ?   Char
                :   Characters[search(Char,Characters)[0]%26]
        ]
    )
;
