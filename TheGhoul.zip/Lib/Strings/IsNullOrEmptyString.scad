/*
    Returns true if input is a null or empty string.
*/
function IsNullOrEmptyString(String)=
    String == undef || String == ""
;
