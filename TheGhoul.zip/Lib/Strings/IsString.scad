/*
    Returns true if input is a string.

    NOTE: Color-definition strings like "#F80A44" are NOT considered strings!
 */
function IsString(String)=
    String==str(String)&&!(len(String)==7&&String[0]=="#")
;
