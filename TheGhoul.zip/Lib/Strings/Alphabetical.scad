/*
  Sorts letters in string alphabetically. Uppercase letters are grouped before lowercase unless IgnoreCase=true.
*/
function Alphabetical(String,IgnoreCase=false)=
    let(
        _String=IgnoreCase
        ?   UpperCase(String)
        :   String,
        Array=QuickSort([
            for(Char=_String)
                [Char,AsciiMapString(Char)]
        ],1)
    )
    TupleToString([
        for(Item=Array)
            Item[0]
    ])
;
