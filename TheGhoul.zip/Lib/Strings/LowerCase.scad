/*
  Turns uppercase letters in a string to lowercase. Leaves all non-letter symbols unchanged.
*/
function LowerCase(String)=
    let(
        Characters=TupleToString(concat(LowerCase,UpperCase))
    )
    TupleToString(
        [
            for(Char=String)
                undef==search(Char,Characters)[0]
                ?   Char
                :   Characters[search(Char,Characters)[0]%26]
        ]
    )
;
