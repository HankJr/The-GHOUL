/*
  A bit like ord() but not really.

  A 'shorthand' alias of MapString().

  Returns an array filled with the Unicodes of the input string.
  See the 'AsciiCharacters' declaration in 'Config.scad', only tab, line-feed and carriage-return (are you old enough to know what that means ;-), space and printable characters up to '~' (Ascii 9,10,13 and 32 through 126.) are included in this string.
*/
function UniCodeMapString(String) =
    MapString(String,UniCodes,AsciiCharacters)
;
