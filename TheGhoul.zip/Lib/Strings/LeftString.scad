/*
  Returns the left part of a string. End>=0 ends at End, End<0 ends at abs(End) from the end of String.
*/
// Errortrap and redirect.
function LeftString(String,End)=
    let(
        _End=Dex(End,Len(String)),
        Foo=Alert(["End out of range at ",End,", mapped onto ",_End,"."],0,abs(End)>Len(String))
    )
    SubString(String,0,_End)
;
