/*
  Returns the right part of a string. Start>=0 starts at Start, Start<0 starts at abs(Start) from the end of String.
*/
// Errortrap and redirect.
function RightString(String,Start)=
    let(
        _Start=Dex(Start,Len(String)),
        Foo=Alert(["Start out of range at ",Start,", mapped onto ",_Start,"."],0,abs(Start)>Len(String))
    )
    SubString(String,_Start,Len(String))
;
