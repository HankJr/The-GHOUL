/*
  Split a string into an array. Add 'padding' characters if requested OutputLength is greater than len(String)-1.
*/
function StringToTuple(String,OutputLength=undef,Padding="")=
    let(
        StringLength=Len(String),
        _Padding=str(Padding)
    )
    undef==OutputLength
    ?   [for(C=String) C]
    :   [for(I=[0:OutputLength])I>StringLength?_Padding:String[I]]
;
