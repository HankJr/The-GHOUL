/*
  Prefix a string with any character to a determined total length.
  Originally written to help generate UniCode numbers.
*/
function Prefix(String,Length=4,Prefix="0")=
    len(String)>=Length
    ?   String
    :   Prefix(str(Prefix,String),Length,Prefix)
;
