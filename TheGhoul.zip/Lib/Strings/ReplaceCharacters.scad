/*
  ReplaceCharacters("TUeH","DOa","TheGHOUL") => "DhaGOOL"
*/
function ReplaceCharacters(InChars,OutChars,String)=
    TupleToString(
        [
            for(Char=String)
                let(
                    Idex=search(Char,InChars)[0],
                    ReplaceChar=undef==OutChars[Idex]
                    /* InChars not in OutChar are scrubbed. */
                    ?   ""
                    :   OutChars[Idex]
                )
                undef==Idex
                /* Anthing not in *InChars* remains unchanged. */
                ?   Char
                :   ReplaceChar
        ]
    )
;
