/* This is the closest my eyes _and my screen_ will let me get to the native OpenSCAD 'golden yellow'. This can be used when you don't want a cutting surface to show up green, simply 'color(OSG)' your difference() objects. Maybe I worry too much... OSG=_O_pen_S_CAD_G_old*/
OSG="#F9D62D"; /* Set to #F9D62D but #FFDD33 isn't bad either. */
/* In case you want to simulate a cut surface, this is that insipid green... Not that I can think why. */
OSC="#9CCC51";

/* Some more colors. By the way: OpenSCAD decimal notation like [0.9,0.5,0.2] gets lost in the html tags used in Echo()** &c., so: Stick to hex notation. I like 'nice round' numbers, but if you're a stickler, I've included the 'official' W3 color codes in the comments.*/
/* **We've since lost the html parsing in the console due to some 'improvements' in the code... SMFH. */
BLK="#000000"; /* Black. */
GRY="#808080"; /* Gray. */
WHT="#FFFFFF"; /* White. */
// Basic colors also for Coordinate system and UCS. --------
RED="#FF0000"; /* Red. */
CYN="#00FFFF"; /* Cyan, opposite of RED. */
GRN="#00FF00"; /* Green. */
MGT="#FF00FF"; /* Magenta, opposite of GRN. */
BLU="#0000FF"; /* Blue. */
YLW="#FFFF00"; /* Yellow, opposite of BLU. */
// Pretty colors. IMNSHO. ----------------------------------
// W3 versions, when different, in the comments; in case you're a stickler.
GPG="#999999"; /* GraphPaper() grey, silver-grey-ish. */
CHK="#252525"; /* Charcoal. */
OLV="#808000"; /* Olive. */
BRN="#994400"; /* Brown.            W3: #964B00 */
DBN="#332200"; /* Dark Brown        W3: #654321 */
DBL="#000080"; /* Dark Blue.        W3: #00008B */
DGN="#008000"; /* Dark Green.       W3: #006400 */
DOG="#FF8000"; /* Dark Orange.      W3: #FF8C00 */
DRD="#800000"; /* Dark Red.         W3: #8B0000 */
DSG="#2F4F4F"; /* Dark Slate Grey. */
ORD="#FF4400"; /* Orange Red.       W3: #FF4500 */
CPR="#DD7711"; /* Copper, not unlike DOG, but, hey... */
PRP="#990099"; /* Purple.           W3: #800080*/
MNB="#252595"; /* Midnight Blue.    W3: #191970 */
GRG="#336644"; /* Green Grey. */
SVR="#C0C0C0"; /* Silver. */
// Since there's DBL &c...
DCN="#008080"; /* DarkCyan. */
DMT="#800080"; /* DarkMagenta. */
DYW="#808000"; /* DarkYellow. */
