
Giga=1e9;
Mega=1e6;
Kilo=1000;
Hecto=100;
Deca=10;

Deci=1/Deca;
Centi=1/Hecto;
Milli=1/Kilo;
Micro=1/Mega;
Nano=1/Giga;

MM=1;
CM=10;
DM=100;
M=1000;
DAM=M*10;
HM=M*100;
KM=M*1000;

Inch=1;
Thou=Inch/1000;
Foot=12*Inch;
Yard=3*Foot;
Mile=1760*Yard; // 5280 feet 1609.344 m
Furlong=220*Yard;
Fathom=6*Foot; // officially 6.08 feet or 1/1000 Admiralty mile
AdmiraltyMile=6080*Foot;
NauticalMile=6076.1*Foot; // 1852 m
Cable=NauticalMile/10; // 100 Fathoms
Chain=66*Foot;
Link=Chain/100; //
Rod=Chain/4; // 16'-6"

/* This may be a bit trivial... Use with or without input.*/
function MM_Inch(mm=1)=
    /* 5 inch is 127 mm. */
    mm*5/127
;

function Inch_MM(Inch=1)=
    /* 5 inch is 127 mm. */
    Inch*127/5
;

function Foot_M(Foot=1)=
    /* 5000 feet is 1524 metres. */
    Foot/5000*1524
;
