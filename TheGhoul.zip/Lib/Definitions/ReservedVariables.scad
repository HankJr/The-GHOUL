/*
    Name            Used by             Function
    $Debug          Config.scad         Debugging flag
    $Verbose        Config.scad         Verbosity flag
    $AnimSegs       -various            Stores animation duration value
    $SVGC           SVG.scad            SVG Coordinates flag
    $Array          -various            Array holder for iterative fx
    $Value          -various            Value holder for iterative fx
    $len            Dex.scad            Stores array length
*/

/*
  Some variables are used as defaults in function calls, so they are defined here to prevent "WARNING: Ignoring unknown variable..." in the console.
*/
// Default settings
$Array=undef;
$Value=undef;
$Len=undef;
