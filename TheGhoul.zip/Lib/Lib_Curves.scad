/*
  <GHOUL/Lib/Lib_Curves.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

include<Curves/ALine.scad>
include<Curves/Arc.scad>
include<Curves/ArcAngles.scad>
include<Curves/CircleAngles.scad>
include<Curves/Circle.scad>
include<Curves/CurveLength.scad>
include<Curves/CurveOffset.scad>
include<Curves/FindCurveVertex.scad>
include<Curves/HLine.scad>
include<Curves/Line.scad>
include<Curves/VLine.scad>

// Not in Geany configuration files, but the routines are...
include<Curves/Roulettes.scad> /* Contains Hypotrochoid() and Epitrochoid()
                                  and some other fun routines. */
include<Curves/Segments.scad>
include<Curves/TangentPoint.scad>
