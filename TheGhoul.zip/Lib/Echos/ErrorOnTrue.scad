/*
  Returns 'false' if Boolean=false, halts execution with message if Boolean=true, this allows you to do:

  if(ErrorOnTrue("Aperture too large", Aperture>2.8))
    DoSomethingWhenApertureIsOkay()
*/
function ErrorOnTrue(StringsTuple=[],Boolean=true)=
    Boolean
    ?   echo(TupleToString(
            StringsTuple==[]
            /* Now we have to do stupid stuff to make text stand out in the console. RIP html rendering, died 2021.01. */
            ?   ["###### ERROR ON TRUE."]
            :   concat(["###### ERROR: "],StringsTuple)
        ))assert(false)
    :   false
;

module ErrorOnTrue(StringsTuple=[],Boolean=true){
    Foo=ErrorOnTrue(StringsTuple,Boolean);
}
