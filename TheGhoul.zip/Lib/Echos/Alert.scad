/*
  Alert() is similar to Print() in that it has a conditional Boolean to be used to only alert under certain conditions, or leave it 'true' for unconditional alerts. It returns Value, default=0.

  Value allows for stuff like:

  Point=[X,Y]+Alert(["Point is [0,0]"], Value=[0,0], (X+Y)==0)
  Color=[X,Y,Z]+Alert([[X,Y,Z]," has red."], Value=[0,0,0], X!=0)

*/
function Alert(StringsTuple=[],Boolean=true,Value=0)=
    Boolean
    /* Now we have to do stupid stuff to make text stand out in the console. RIP html rendering, died 2021.01. */
    ?   echo(TupleToString(concat(["<<<<<< ALERT >>>>>>: "],StringsTuple)))Value
    :   Value
;

module Alert(StringsTuple=[],Boolean=true,Value=0){
    Foo=Alert(StringsTuple,Boolean,Value);
}
