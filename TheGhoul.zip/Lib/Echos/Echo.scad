/*
  Echo() should be the default for user feedback. By default it is $Verbose sensitive, so experienced users can silence the output. Echo() returns *Value*, mostly to maintain the same functionality across all the echo() related functions in TheGHOUL.

  StringsTuple  -- tuple, a tuple containing any mixture of values and strings, this will be converted to a string and printed to the console.
*/
function Echo(StringsTuple=[],Boolean=$Verbose,Value=0)=
    Boolean
    ?   echo(TupleToString(StringsTuple))Value
    :Value
;

module Echo(StringsTuple=[],Boolean=$Verbose,Value=0){
    Foo=Echo(StringsTuple,Boolean,Value);
}
