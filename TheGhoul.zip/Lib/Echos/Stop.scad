/*
  Stop execution and echo a message. Returns no value.
*/
function Stop(Stringstuple=[])=
    /* Now we have to do stupid stuff to make text stand out in the console. RIP html rendering, died 2021.01. */
    echo(TupleToString(concat(["###### STOPPED "],Stringstuple)))assert(false)
;

/* Provide a module for 'stand-alone' use. */
module Stop(Stringstuple=[]){
    Foo=Stop(Stringstuple);
}
