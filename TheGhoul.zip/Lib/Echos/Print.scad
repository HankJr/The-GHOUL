/*
  Print() is the most flexible of the echo routines, allowing for conditional output as well as value definition, by default it always prints to the console.
*/
function Print(StringsTuple=[],Boolean=true,Value=0)=
    Boolean
    ?   echo(TupleToString(StringsTuple))Value
    :   Value
;

/* Provide a module for 'stand-alone' use. */
module Print(StringsTuple=[],Boolean=true,Value=0){
    Foo=Print(StringsTuple,Boolean,Value);
}
