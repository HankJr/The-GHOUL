/*
  Returns 'true' if Boolean=true, halts execution with message if Boolean=false, this allows you to do:

  if(ErrorOnFalse("Aperture too large", Aperture<2.8))
    DoSomethingWhenApertureIsOkay()
*/
function ErrorOnFalse(StringsTuple=[],Boolean=false)=
    Boolean
    ?   true
    :   echo(TupleToString(
            StringsTuple==[]
            /* Now we have to do stupid stuff to make text stand out in the console. RIP html rendering, died 2021.01. */
            ?   ["###### ERROR ON FALSE."]
            :   concat(["###### ERROR: "],StringsTuple)
        ))assert(false)
;

module ErrorOnFalse(StringsTuple=[],Boolean=false){
    Foo=ErrorOnFalse(StringsTuple,Boolean);
}
