/*
  Returns the developed length of a Bézier curve.
*/
function BezierCurveLength(ControlPolygonSet,Resolution=10)=
    CurveLength(BezierCurve(ControlPolygonSet,Resolution))
;

