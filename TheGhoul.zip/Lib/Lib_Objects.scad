/*
  <GHOUL/Lib/Lib_Objects.scad>

  Hank J. van Leuvensteijn Jr. 2019
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

// Objects
include<Objects/Arrow.scad>
include<Objects/ArrowArc.scad>
include<Objects/ArrowHead.scad>
include<Objects/BallCylinderBetween.scad>
include<Objects/Calendar.scad>/* TODO */ // Contains multiple routines.
include<Objects/Cap.scad>
include<Objects/CylinderBetween.scad>
include<Objects/CoordinateSystem.scad>
include<Objects/Dimension.scad>
include<Objects/GraphPaper.scad>
include<Objects/Protractor.scad>
include<Objects/Ruler.scad>
include<Objects/SimpleGauge.scad>
include<Objects/StarCap.scad>
include<Objects/TheGHOUL.scad>
include<Objects/Waterline.scad>
include<Objects/WaterMark.scad>

// May need some work on these... 3D polyhedrons
include<Objects/ChamferedBar.scad>
include<Objects/ChamferedCube.scad>
include<Objects/ChamferedCylinder.scad>

// Stuff... Not in the Geany config files, but should we?
include<Objects/ToonCar.scad>
include<Objects/ToonPlane.scad>

