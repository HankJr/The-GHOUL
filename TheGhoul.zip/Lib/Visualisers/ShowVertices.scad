module ShowVertices(Array,Vertices=undef,Radius=0.5,Color=RED){

    N=Len(Array);
    IsNoArray=Len(Array[0])==undef;
    IsOneVertex=(IsNoArray&&N<3);

    if(IsOneVertex)
    /* We have a single vertex. */
    {
        color(Color)
        translate(Array)
        sphere(r=Radius);
    }
    else
    /* We have an array of vertices. */
    {
        _Vertices=
            Vertices==undef
            /* Show all vertices. */
            ?   [0:N]
            :   Vertices==[]
                /* Show first and last pair. */
                ?   [0,1,N-1,N]
                :   Vertices;

        color(Color)
        for(Vertex=_Vertices)
        translate(Vertex)
        sphere(r=Radius);
    }
}
