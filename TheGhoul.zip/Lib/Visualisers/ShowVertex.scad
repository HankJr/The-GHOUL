/*
 Used in debugging new shapes for Shapes.scad library and so on.
*/
module ShowVertex(Vertex,Radius=0.5,Color=RED){
    color(Color)
    translate(Vertex)
    sphere(r=Radius);
}
