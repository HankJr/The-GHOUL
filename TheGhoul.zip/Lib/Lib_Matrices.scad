/*
  <GHOUL/Lib/Lib_Matrices.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

include<Matrices/AffinePosition.scad>
include<Matrices/AffineRotate.scad>
include<Matrices/AffineScale.scad>
include<Matrices/AffineTransform.scad>
include<Matrices/AffineTranslate.scad>
include<Matrices/HomogeniseMatrix.scad>
include<Matrices/IdentityMatrix.scad>
include<Matrices/MatrixTranspose.scad>
include<Matrices/RotationMatrix.scad>
include<Matrices/ScalingMatrix.scad>
include<Matrices/ShearingMatrix.scad>
include<Matrices/TransformMatrix.scad>
include<Matrices/TranslationMatrix.scad>
