/*

  <GHOUL/Lib/Lib_Parts.scad>

  Hank J. van Leuvensteijn Jr. 2021
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.

*/

/* Biggies get their own Parts/Subdirectory. */
include<Parts/Belts/TimingBelt.scad>/* TODO */
include<Parts/Belts/TimingBeltData.scad>/* TODO */

include<Parts/Clocks/ClockBits.scad>
include<Parts/Clocks/CamWheel.scad>
include<Parts/Clocks/ChainWheel.scad>
include<Parts/Clocks/Click.scad>
include<Parts/Clocks/ClockCycloidGear.scad>
include<Parts/Clocks/CountWheel.scad>
include<Parts/Clocks/DeadBeatEscapement.scad>
include<Parts/Clocks/EquationOfTime.scad>
include<Parts/Clocks/LanternGear.scad>
include<Parts/Clocks/Snail.scad>

include<Parts/Gears/InvoluteGear.scad>
include<Parts/Gears/InvoluteGearTooth.scad>
include<Parts/Gears/Rack.scad>
include<Parts/Gears/RackTooth.scad>
include<Parts/Gears/UnderCut.scad> // Not in Geany setup.

include<Parts/Threads/Thread.scad>
include<Parts/Threads/ThreadData.scad> // Not in Geany setup.

/* These are in /Parts. */
include<Parts/KnurledCylinder.scad>
include<Parts/PicatinnyRail.scad> // Todo: Needs work.
include<Parts/SimpleThread.scad>
