/*
  <GHOUL/Lib/Lib_Modifiers.scad>

  Hank J. van Leuvensteijn Jr. 2019
  hankjr@hankjr.ca

  The GHOUL (Great Helpful OpenSCAD Unified Library) is set free under the unlicense:

  Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form or as a compiled binary, for any purpose, commercial or non-commercial, and by any means.
*/

// Modifiers
include<Modifiers/CircularArray.scad>
include<Modifiers/LinearArray.scad>
include<Modifiers/OutRadius.scad>
include<Modifiers/Position.scad>
include<Modifiers/PosX2D.scad>
include<Modifiers/PosX3D.scad>
include<Modifiers/PosZ3D.scad>
include<Modifiers/ScreenCoords.scad>
include<Modifiers/ScreenMove.scad>
include<Modifiers/ScreenPosition.scad>
include<Modifiers/ScreenUCS.scad>
include<Modifiers/SectorCut.scad>
include<Modifiers/SectorSlice.scad>
include<Modifiers/Torus.scad>
include<Modifiers/Tumble.scad>
