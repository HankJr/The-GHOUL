/*
  Crop everything below Z=0 (3D).
*/
module PosZ3D(Size){
    difference(){
    children();
    translate([0,0,-Size/2])
    cube([Size,Size,Size],center=true);
    }
}

