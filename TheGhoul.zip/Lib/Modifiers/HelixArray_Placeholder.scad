module HelixArray(Radius=10,Turns=1,NumberPerTurn=8,Pitch=4,Handedness="Right"){

    Elements=Turns*NumberPerTurn;
    AngleStep=360/NumberPerTurn;
    PitchStep=Pitch/NumberPerTurn;



    children();
}

/* TODO: This */

/*
  Or maybe CurveArray(), an array of objects along a 2D or 3D curve.
*/
