/*
  Circles, and thus holes, in OpenSCAD are not round but actually $fn-agons
  that fit INSIDE the specified radius.

  Open GHOUL/DemoFiles/Img_OutRadius.scad in OpenSCAD for a visual explanation.

  To get a hole that has minimum dimensions of exactly the required radius,
  let's say 10, use a call like this:

  | circle(r=10*OutRadius());
    or
  | circle(r=OutRadius(10)); (See sidebar below!)

  Since OutRadius() is called from _within_ the circle() call, it always gets the correct, local value of $fn, even if there is a $fn assignment inside the circle() call.

  OutRadius(r,Rate)
  r:    scalar; radius.
  Rate: factor; default=1, usually, you're looking for the default.

  * ATTENTION: Specifying the radius in the OutRadius() call affects the
  * result: OutRadius() calls Segments(), which uses the radius *r* to decide
  * in how many segments a circle is divided, which has a direct impact on the
  * 'outradius factor'. Perhaps you should read the documentation at Segments().
*/
function OutRadius(r=undef,Rate=1)=
    (1+(1/cos(180/Segments(r))-1)*Rate)*(r==undef?1:r)
;
