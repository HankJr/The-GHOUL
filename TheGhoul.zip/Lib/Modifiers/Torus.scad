/* TODO manipulate and covermesh, add twist?
  As of yet, it's just a name place-holder and an alias for rotate_extrude(),
  future additions will make this more useful.
*/
module Torus(Radius,Angle){
    _Angle=Angle==undef
    ?   360
    :   Angle;
  rotate_extrude(angle=_Angle) translate([Radius,0]) children();
}

