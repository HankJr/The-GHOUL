// TODO make more general like CropX(Size, Pos/Neg side of X= any coordinate)
/*
  Crop everything to the 'left' of X=0 (2D).
*/
module PosX2D(Size){
    difference(){
    children();
    translate([-Size/2,0,0])
    square([Size,Size],center=true);
    }
}

