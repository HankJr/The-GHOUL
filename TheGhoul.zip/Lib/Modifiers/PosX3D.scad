// TODO make more general like CropX(Size, Pos/Neg side of X= any coordinate)
/*
  Crop everything to the 'left' of X=0 (3D).
*/
module PosX3D(Size){
    difference(){
    children();
    translate([-Size/2,0,0])
    cube([Size,Size,Size],center=true);
    }
}

