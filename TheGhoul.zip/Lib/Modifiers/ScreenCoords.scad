/*
  Turns 'world' vertices into  'screen' vertices (or vectors).
*/
function ScreenCoords(Vertex)=
    let(
        SC=ScreenUCS()
    )
    SC.x*Vertex.x+SC.y*Vertex.y+SC.z*Vertex.z
;

