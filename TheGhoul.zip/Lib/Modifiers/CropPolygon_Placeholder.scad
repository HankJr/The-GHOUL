/* TODO: This */

// chop a piece off the polygon, left or right of X=constant etc.
function CropPolygon()=
 "Placeholder"
 ;
