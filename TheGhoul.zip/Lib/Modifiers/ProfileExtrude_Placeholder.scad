/* TODO: this */
/*
  Take a shape (closed curve) in X-Y.
  Take a profile (curve) in X-Z.
  Extrude the shape 'along' the profile.
*/
// or
/*
  'Bend' a shape (array of vertices on the X-Y plane forming a shape) along a curve that lies in the Y-Z plane, or a 3D curve, e.g. a helix.

  rather than just assigning the Z value of the curve's vertices to the shape vertices that share it's X-value, the shape has to be 'wrapped' onto the curve, i.e., place the shape vertices on the curve where the curve's developed length equals the shape vertex's X-value.

  It may be preferable to rotate the shape upright and describe the curve in the X-Y plane as well, akin to the 'rotate_extrude()' methodology.
*/
