/*TODO 2D behaviour
  Used to cut a sector out of children().
*/
module SectorCut(StartAngle,EndAngle,Radius,Height,Centered=true,Move=[0,0,0],Color=BLK,Convexity=10,Lap=Cut)
{
    difference(){
        children();
        color(Color)
        translate(Move+[0,0,Centered?0:-Lap/2])
        linear_extrude(height=Height+Lap,center=Centered,convexity=Convexity)
        Sector(StartAngle,EndAngle,Radius+Lap/2);
    }
}

