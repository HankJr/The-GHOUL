module ToonPlane(C1=PRP,C2=CPR,C3=DSG,Alpha=1){

// Fuselage
color(C1,Alpha)
rotate([0,-90,0])
PosZ3D(20)
scale([1,1,7])
sphere(r=1);

color(C1,Alpha)
rotate([0,90,0])
PosZ3D(20)
scale([1,1,3])
sphere(r=1);

// Wing
color(C2,Alpha)
rotate([90,90,0])
scale([0.4,1.2,7])
sphere(r=1);

// Empennage
color(C3,Alpha)
translate([-6,0,0])
rotate([90,90,0])
scale([0.25,0.75,3])
sphere(r=1);

color(C3,Alpha)
translate([-6,0,0])
rotate([0,0,90])
PosZ3D(20)
scale([0.25,0.75,2])
sphere(r=1);

// Nacelles
color(C1,Alpha)
translate([1.2,2.5,0])
rotate([0,-90,0])
PosZ3D(20)
scale([0.5,0.5,2.5])
sphere(r=1);

color(C1,Alpha)
translate([1.2,-2.5,0])
rotate([0,-90,0])
PosZ3D(20)
scale([0.5,0.5,2.5])
sphere(r=1);

// Spinners
color(DSG,Alpha)
translate([1.2,2.5,0])
rotate([0,90,0])
PosZ3D(20)
scale([0.3,0.3,0.5])
sphere(r=1);

color(DSG,Alpha)
translate([1.2,-2.5,0])
rotate([0,90,0])
PosZ3D(20)
scale([0.3,0.3,0.5])
sphere(r=1);

// Propellers
color("silver",0.3)
translate([1.2,2.5,0])
rotate([0,90,0])
linear_extrude(0.1)
circle(r=1);

color("silver",0.3)
translate([1.2,-2.5,0])
rotate([0,90,0])
linear_extrude(0.1)
circle(r=1);

}
