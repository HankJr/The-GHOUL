/* Quick and dirty temporary watermark. */
module WaterMark(Location=[5.5,7,0],Size=1,Text="WaterMark is on.")
{
    Print([Text]);

    TheGHOUL(Location=Location,Size=Size);
}
