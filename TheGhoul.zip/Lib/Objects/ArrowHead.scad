
function ArrowHead(Width,Point,Barb)=
    let(
        Vertices=[
            [0,0],[-Barb,Width/2],[Point,0],[-Barb,-Width/2]
        ],
        Faces=[
            [0,1,2,3]
        ]
    )
    [Vertices,Faces]
;
module ArrowHead(Width,Point,Barb){
    A=ArrowHead(Width,Point,Barb);
    polygon(A[0],A[1],2);
}
