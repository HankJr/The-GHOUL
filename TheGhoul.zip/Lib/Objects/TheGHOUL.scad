/* Image watermark... */
module TheGHOUL(Location=[0,0,0],Twist=[15,30,0],Thickness=0.1,Size=1,Color=DSG,Alpha=1/10){

    Font="MathJax_Typewriter";
//    Font="Noto Sans Black";

    color(Color,Alpha)
    ScreenPosition(Location)
    rotate(Twist)     /* 3D-ify the text. */
    SimpleText("The GHOUL",
        Size=Size,Thickness=Thickness,Center=true,
        Font=Font,Spacing=1
    );
}
