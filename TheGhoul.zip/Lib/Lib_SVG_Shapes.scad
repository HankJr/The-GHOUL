/*
  List all shape collections in the SVG/Shapes/ directory that you want to include.
*/
include<SVG/Shapes/FavIcons.scad>
include<SVG/Shapes/DemoShapes.scad>
