function Rad(Degrees)=
    Degrees/360*Tau
;
