/* This is a helper routines for Intermediate(), it's not in the documentation. Yet. */

/*
  Turn an OpenSCAD color tuple like [1,0.5,0] into a hex-color string like "#FF8000".
*/
function ColorTupleToHex(ColorTuple)=
    str(
        "#",
        Prefix(DecToHex(ColorTuple[0]*255),2,"0"),
        Prefix(DecToHex(ColorTuple[1]*255),2,"0"),
        Prefix(DecToHex(ColorTuple[2]*255),2,"0")
    )
;
