/*
    OrIsTrue([2 > 4, 5 < 0, "ed" == "ted"]) => false
    OrIsTrue([2 > 4, 5 < 0, "ed" == "ed"]) => true
*/
function OrIsTrue(Expressions)=
    /* Foo=false and Bar=true. */
    /* (Foo==true || Bar==true) is equivalent to !(Foo==false && Bar==false). */
    /* (false || true) is equivalent to !(true && false). */
    !_AndIsFalse(Expressions,Len(Expressions))
;
