/* Trivial, I know... */
function Sqrt(Value)=pow(Value,0.5);
function Pow2(Value)=pow(Value,2);
function Pow3(Value)=pow(Value,3);
function Pow10(Value)=pow(Value,10);
