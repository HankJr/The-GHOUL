/*
  Find intersection of a radial (line through the origin) of known direction (angle) with a line segment between two known points.
*/
