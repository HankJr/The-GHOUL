/* Nearest odd value*/
function NearestOdd(Value)=
    MFloor(Value,2)+1
;
