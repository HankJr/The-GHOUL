/*
  Floor with 'factor' function. Rounds down to the nearest multiple of 'Factor'.
  MFloor(5.31,0.25) -> 5.25
*/
function MFloor(Value,Factor)=
    floor(Value/Factor)*Factor
;
