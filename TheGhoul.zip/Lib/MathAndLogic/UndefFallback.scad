/*
  Replaces _only_ undef with 'Replacement' value.
  * Also works as 'IsUndef()', as UndefFallback(undef) returns _true_.
*/
function UndefFallback(Value,Replacement=true)=
    Value==undef
    ?   Replacement
    :   Value
;
