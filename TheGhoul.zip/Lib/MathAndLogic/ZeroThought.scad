/*
  Replaces _only_ 0 with barely anything at all.
  Thought=1/8192;
*/
function ZeroThought(Value)=
    Value==0
    ?   Thought
    :   Value
;
/*
  And the 'reverse'.
*/
function ThoughtZero(Value)=
    is_list(Value)
    ?   [ for(Item=Value) abs(Item)<Thought?0:Item ]
    :   abs(Value)<Thought?0:Value
;
