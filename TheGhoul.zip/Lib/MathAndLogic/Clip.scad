/*
  Clip 'Value' to VMin/VMax. If Value lies between VMin and VMax, inclusive,
  it will remain unchanged.
  If Value lies below VMin, VMin will be returned,
  if Value lies above VMax, VMax will be returned.
  A bit trivial but it makes for more readable code. Probably.

  * Use as Clip(Index,Len(SomeArray)) to get limit cases for out of bounds indices...
 */
function Clip(Value,Max=1,Min=0)=min(max(Value,Min),Max);
