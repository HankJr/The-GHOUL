/* This is a helper routine for Intermediate(). */

/*
  Turn a hex-color string like "#FF8000" into an OpenSCAD color tuple like [1,0.5,0].
*/
function ColorHexToTuple(HexColor)=
    [
        for(Idex=[1,3,5])
        HexToDec(str(HexColor[Idex],HexColor[Idex+1]))/255
    ]
;

