/*
  Replaces _only_ 0 with 'Replacement' value or 'FrogsHair'.
  FrogsHair=1/16384, i.e, 1/(2^14).
*/
function ZeroFallback(Value,Replacement=FrogsHair)=
    Value==0
    ?   Replacement
    :   Value
;
