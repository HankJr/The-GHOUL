function DecToHex(Dec,Hex="")=
    // is remainder less than 16
    Dec<16
    // prepend remainder value character to Hex string
    ?   str(HexCharacters[Dec],Hex)
    // iterate with value divided by 16 minus remainder
    :   DecToHex(floor(Dec/16),
            // prepend remainder value character to Hex string
            str(
                HexCharacters[((Dec/16)-floor(Dec/16))*16]
            ,Hex)
        )
;
