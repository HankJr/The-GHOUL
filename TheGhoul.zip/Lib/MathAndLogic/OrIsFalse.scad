/*
    OrIsFalse([2 == 2, 5 > 0, "ed" == "ed"]) => false
    OrIsFalse([2 == 2, 5 < 0, "ed" == "ed"]) => true
*/
function OrIsFalse(Expressions)=
    /*
      Foo=false and Bar=true
      (Foo==false || Bar==false) is equivalent to !(Foo==true && Bar==true)
      (true || false) is equivalent to !(false && true)
    */
    !_AndIsTrue(Expressions,Len(Expressions))
;
