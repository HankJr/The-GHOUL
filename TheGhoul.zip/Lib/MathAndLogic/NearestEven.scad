/* Nearest even value */
function NearestEven(Value)=
    MFloor(Value+1,2)
;
