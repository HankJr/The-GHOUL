/*
    AndIsTrue([2 == 2, 5 > 0, "ed" == "ed"]) => true
    AndIsTrue([2 == 2, 5 > 0, "ted" == "ed"]) => false
*/
function AndIsTrue(Expressions)=
    _AndIsTrue(Expressions,Len(Expressions))
;

function _AndIsTrue(Expressions,Index)=
    Index<0
    /* No falsehood found. */
    ?   true
    :   Expressions[Index]
        /* A truth, check the next. */
        ?   _AndIsTrue(Expressions,Index-1)
        /* Oops, found a falsehood. */
        :   false
;
