/* Convert Radians into degrees. */
function Deg(Radians)=
    Radians/Tau*360
;
