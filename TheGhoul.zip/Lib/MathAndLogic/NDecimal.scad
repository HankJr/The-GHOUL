/*
  0 based decimal:
  NDecimal(12.1234567,3)=4
*/
function NDecimal(Value,N)=
    str(Value-floor(Value))[N+2]
;
