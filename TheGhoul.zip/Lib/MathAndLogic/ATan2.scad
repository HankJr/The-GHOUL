function ATan2(X,Y)=
    (atan2(Y,X)+360)%360
;
