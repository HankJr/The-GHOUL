/*
  Ceiling with 'factor' function. Rounds up to the nearest multiple of 'Factor'.
  MCeil(5.31,0.25) -> 5.5
*/
function MCeil(Value,Factor)=
    ceil(Value/Factor)*Factor
;
