/*
    AndIsFalse([2 > 4, 5 < 0, "ted" == "ed"]) => true
    AndIsFalse([2 > 4, 5 < 0, "ed" == "ed"]) => false
*/
function AndIsFalse(Expressions)=
    _AndIsFalse(Expressions,Len(Expressions))
;

function _AndIsFalse(Expressions,Index)=
    Index<0
    /* No truth found, all is falsehood. */
    ?   true
    :   Expressions[Index]
        /* Oops. Found a truth. */
        ?   false
        /* A falsehood, check the next. */
        :   _AndIsFalse(Expressions,Index-1)
;
