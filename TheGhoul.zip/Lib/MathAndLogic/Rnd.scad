function Rnd(Seed=undef)=
    undef==Seed
    ?   rands(0,1,1)[0]
    :   rands(0,1,1,Seed)[0]
;
