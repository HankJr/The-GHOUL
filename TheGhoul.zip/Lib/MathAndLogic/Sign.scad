/* Returns 1 or -1 commensurate with the sign of 'Value'. Unlike the native sign(), this does *not* return '0' when value=0, but '1'.*/
function Sign(Value)=
    Value<0
    ?   -1
    :   1
;
