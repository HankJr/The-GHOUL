/*
  ALL 'Is...' logic in one file, regardless of whether dealing with strings, numbers or whatever.
*/
/* TODO: IsUcode() unicode  */
/*
    The following functions make for more readable code, but may not necessarily be all that useful. You're the judge. Use with caution; make sure you know what type you're testing and the possible results!!!
*/
function IsEven(I)= I%2==0?true:false;

function IsOdd(I)= I%2==1?true:false;

function IsInteger(I)= I%1==0?true:false;

function IsNotInteger(I)= I%1!=0?true:false;

function IsFraction(I)= (0<I&&I<1)?true:false;

function IsNumber(I)=((undef!=I*1)&&(undef==len(I)))?true:false;

function IsPositive(I)= I>0?true:false;

function IsNegative(I)= I<0?true:false;

/*
  Yep. Returns 'true' when 'Year' is a leap-year. Whodathunkit.
*/
function IsLeapYear(Year)=
    Year%4==0 && (Year%100!=0 || Year%400==0)
;

