/*
  Crop value to *Decimals*.

  Decimals(1.2345,2) => 1.23
*/
function Decimals(Value,Decimals)=
    MRound(Value,1/pow(10,Decimals))
;
