/*
  Round with 'factor' function. Rounds to the nearest multiple of 'Factor'.
  MRound(5.31,0.25) -> 5.25
*/
function MRound(Value,Factor)=
    round(Value/Factor)*Factor
;

