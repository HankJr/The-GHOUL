/*
  Removes all _undef_ values from an array.
*/
function RemoveUndefs(Array)=
    _RemoveUndefs(Array,Len(Array),[])
;

function _RemoveUndefs(Array,Index,Result)=
    Index<0
    ?   Result
    :   undef==Array[Index]
        ?   _RemoveUndefs(Array,Index-1,Result)
        :   _RemoveUndefs(Array,Index-1,concat([Array[Index]],Result))
;
