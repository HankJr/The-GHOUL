/* Drop the head of an array. */
function RightArray(Array,Begin)=
    let(
        End=Len(Array),
        Start=Dex(Begin,End),
        Foo=Alert(["Begin out of range at ",Begin,", mapped onto ",Start,"."],0,abs(Begin)>End)
    )
    [ for (Index = [Start:End])
            Array[Index]
        ]
;
