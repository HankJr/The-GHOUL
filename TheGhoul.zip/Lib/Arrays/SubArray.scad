/* It does what it says... */
function SubArray(Array,Start=0,End=-1)=
    let(
        _Start=Dex(Start,Len(Array)),
        Foo=Alert(["Start= ",Start," and out of range, mapped onto ",_Start,"."],0,abs(Start)>Len(Array)),
        _End=Dex(End,Len(Array)),
        Bar=Alert(["End= ",End," and out of range, mapped onto ",_End,"."],0,abs(End)>len(Array))
    )
    _End<_Start
    ?   undef
    :   [ for (Index = [_Start : _End])
            Array[Index]
        ]
;

