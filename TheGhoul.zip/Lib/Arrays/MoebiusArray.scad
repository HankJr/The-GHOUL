/*
  Address an array as if it were a closed loop
  'Index' [any integer] is mapped onto [0:len(Array)-1], with 0->0.

  Yes, this can (almost) be achieved with Array[Index%len(Array)] but that construct is lost when Index<0, MoebiusArray(Array,-X) however, will give you the ability to address 'X items from the end' &c.
*/
/*
  However... This is just an alias now...
*/
function MoebiusArray(Array,Index)=
    Array[Dex(Index,Len(Array))]
;
