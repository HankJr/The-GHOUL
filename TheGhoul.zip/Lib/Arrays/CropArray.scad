/*
  Crop every tuple in an array down to a certain length, defaults to 2D, for ease of transition from 3D.
*/
function CropArray(Array,Length=2)=
    [
        for(Tuple = Array)
            [for(Index=[0:Length-1])Tuple[Index]]
    ]
;
