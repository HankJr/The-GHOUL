/* Fetch the last element from an array. */
function Last(Array)=Array[Len(Array)];
/* If you have Yin... */
function First(Array)=Array[0];
