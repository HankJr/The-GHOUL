/*
    ReverseArray([1, 2, 3]) => [3, 2, 1]
*/
function ReverseArray(Array)=
    [ for (Index = [Len(Array) : -1 : 0])
        Array[Index]
    ]
;
