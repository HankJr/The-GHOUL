/*
  Selector function for the different Find... functions.
  Not much to say here, it's pretty obvious.
*/
function Find(Value,Array,Condition="EQ",Type="First",Element=0)=
    Condition=="EQ"
    ?   Type=="First"
        ?   _FindEQFirst(Value,Array,Type,Element)
        :   Type=="Last"
            ?   _FindEQLast(Value,Array,Type,Element)
            :   _FindEQAll(Value,Array,Type,Element)
    :   Condition=="GT"
        ?   Type=="First"
            ?   _FindGTFirst(Value,Array,Type,Element)
            :   Type=="Last"
                ?   _FindGTLast(Value,Array,Type,Element)
                :   _FindGTAll(Value,Array,Type,Element)
    :   Condition=="LT"
        ?    Type=="First"
            ?   _FindLTFirst(Value,Array,Type,Element)
            :   Type=="Last"
                ?   _FindLTLast(Value,Array,Type,Element)
                :   _FindLTAll(Value,Array,Type,Element)
    :   Condition=="GTE"
        ?   Type=="First"
            ?   _FindGTEFirst(Value,Array,Type,Element)
            :   Type=="Last"
                ?   _FindGTELast(Value,Array,Type,Element)
                :   _FindGTEAll(Value,Array,Type,Element)
    :   Condition=="LTE"
        ?   Type=="First"
            ?   _FindLTEFirst(Value,Array,Type,Element)
            :   Type=="Last"
                ?   _FindLTELast(Value,Array,Type,Element)
                :   _FindLTEAll(Value,Array,Type,Element)
    :   Condition=="NE"
        ?   Type=="First"
            ?   _FindNEFirst(Value,Array,Type,Element)
            :   Type=="Last"
                ?   _FindNELast(Value,Array,Type,Element)
                :   _FindNEAll(Value,Array,Type,Element)
    :   Print([">>>>> Condition ",Condition," not a valid choice in Find()."],true,undef)
;
