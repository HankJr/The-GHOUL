/*
    Maps index onto [0...max.]

    Dex() maps any index onto [0...Max], *Max* is usually Len(SomeArray), when using Dex() multiple times on the same array, set $Len=Len(array) and simply use Dex(Index).
*/
function NDex(Index,Max=$Len)=
    let(
        Idex=round(Index) // Just in case ;-)
    )
    /* Remember PEMDAS... Or something like that. */
    Max==0
    ?   0
    :   Idex%(Max+1)+(Idex<0?Max+1:0)
;

/* TODO: Figure this out. */

function Dex(Index,Max=$Len)=
    let(
        Idex=round(Index) // Just in case ;-)
    )
    Idex<0
    /* Remember PEMDAS... Or something like that. */
    ?   Max+(Idex+1)%(Max+1)
    :   Idex%(Max+1)
;

