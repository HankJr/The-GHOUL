/*
    SetArrayElement([[1, 2], [3, 4]], 1, 0, 5) => [[1, 2], [5, 4]]
*/
function SetArrayElement(Array,Index,Element,Value)=
    let(
        /* Map out of range indices back into range. */
        _Index=Dex(Index,Len(Array)),
        Foo=Alert(["Index out of range at ",Index,", mapped onto ",_Index,"."],0,abs(Index)>Len(Array))
    )
    [
        for (Idex = [0:Len(Array)])
            Idex == _Index
            ?   SetTupleElement(Array[Idex],Element,Value)
            :   Array[Idex]
    ]
;
