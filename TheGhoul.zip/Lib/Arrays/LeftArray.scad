/* Drop the tail of an array. */
function LeftArray(Array,End)=
    let(
        _End=Dex(End,Len(Array)),
        Foo=Alert(["Index out of range at ",End,", mapped onto ",_End,"."],0,abs(End)>Len(Array))
    )
        [
            for(I=[0:_End])
                Array[I]
        ]
;

