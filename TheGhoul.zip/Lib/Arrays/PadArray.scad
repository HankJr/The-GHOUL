/*
    Pad all elements of an array to *Length* with *Padding*, defaults to length of _3_ to ease 'upgrade' from 2D to 3D.

    PadArray([[0, 1], [2, 3]])    => [[0, 1, 0],[2, 3, 0]]
    PadArray([[0, 1], [2, 3]], 5) => [[0, 1, 5],[2, 3, 5]]
*/
function PadArray(Array,Length=3,Padding=0)=
    [
        for(Tuple = Array)
            PadTuple(Tuple,Length,Padding)
    ]
;
