/*
    IsInArray("s",["d", "t", "s", "h"]) => true
*/
function IsInArray(Element,Array)=
    //search(Element,Array)[0]!=undef

    /* Instead of the above--which ought to be the logical choice--the option below is MUCH more robust, and produces logical and expected results (especially when working with strings) where search() often displays exasperatingly strange behaviour... Sigh... */

    OrIsTrue([for(Index=[0:Len(Array)]) Element==Array[Index]])
;
