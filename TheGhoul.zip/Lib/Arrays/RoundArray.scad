/* Round all values in an array. */
function RoundArray(Array)=
    [
        for(Value=Array)
        round(Value)
    ]
;
