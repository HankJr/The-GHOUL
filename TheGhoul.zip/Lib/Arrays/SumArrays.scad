/*
  Sum the elements 'pairs' of two equal-length arrays
*/
function SumArrays(Array1,Array2)=
    len(Array1)!=len(Array2)
    ?   undef
    :   [
            for(I=[0:len(Array1)-1])
                Array1[I]+Array2[I]
        ]
;
