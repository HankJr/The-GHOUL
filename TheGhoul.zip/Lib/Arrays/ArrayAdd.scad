/*
  Add something to every element in an array.
*/
function ArrayAdd(Array,Additive)=
    [for(Item=Array) Item+Additive ]
;
