/*
    Reduce the order (depth) of an array by 1 'from-the-outside-in'
    FlattenArray([[1,2],[3,4],[5,6],[7,8]]) = [1,2,3,4,5,6,7,8]
*/
function FlattenArray(Array)=
    _FlattenArray(Array,0,Len(Array),[])
;

function _FlattenArray(Array,Index,End,Result)=
    Index>End
    ?   Result
    :   _FlattenArray(Array,Index+1,End,concat(Result,Array[Index]))
;
