/* Sick of typing "-1". */
function Len(Array)=
    /* Since 2021.01 we need these dumb, illogical, unnecessary checks, see comments below. */
    undef==Array
    ?   undef
    :   is_num(Array)
        ?   undef
        :   len(Array)-1
;

/* It is EXTREMELY SAD when you have to rewrite a routine because the language no longer functions logically, efficiently and flawlessly, as it did before some nitwit decided to 'improve' it. Here is the original, sleek version of this routine, which now generates a list of stupid warnings when *Array* is either _undef_ or a number, because len() no longer behaves logically :'( */
function _Len(Array)=
    len(Array)-1
;

/* You'd maybe like to think that this would work. */
/* Edit: This now seems to work (again?)... */
/* TODO: Perhaps make this one Len()? */
function __Len(Array)=
    is_list(Array)
    ?   len(Array)-1
    :   undef
;
/* But for reasons that are too obscure to waste my time on, that completely breaks some code that used to run like a greased machine. */
