/*
  Shift an entire array's elements right.
  What falls off the end becomes the beginning.
    Arrayshift([0,1,2,3,4,5],3)=[3,4,5,0,1,2]
  Why? I don't know...
*/
function ArrayShift(Array,Shift)=
    let(
        /* Turn negative shifts into positive equivalent. */
        _Shift=Dex(Shift,Len(Array)),
        Foo=Alert(["Shift out of range at ",Shift,", mapped onto ",_Shift,"."],0,abs(Shift)>Len(Array))
    )
    [
        for(Idex=[0:Len(Array)])
        /* _Shift is already re-mapped (and thus not negative) so we can safely use the modulo operator. */
        Array[(Idex+_Shift)%len(Array)]
    ]
;
