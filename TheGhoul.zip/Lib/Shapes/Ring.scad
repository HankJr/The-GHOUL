function Ring(Radius,Wall,Centered=true)=
    let(
        Couter=Centered
        ?   Circle(Radius)
        :   ArrayAdd(Circle(Radius),[Radius,Radius]),
        Cinner=Centered
        ?   Circle(Radius-Wall)
        :   ArrayAdd(Circle(Radius-Wall),[Radius,Radius]),
        Fo=len(Couter),
        Fi=len(Cinner)
    )
    [
        concat(
            Couter,
            Cinner
        ),
        [
            [for(Index=[0:Fo-1])Index],
            [for(Index=[Fo:Fo+Fi-1])Index]
        ]
    ]
;
module Ring(Radius,Wall,Centered=true){
    Poly=Ring(Radius,Wall,Centered);
    polygon(Poly[0],Poly[1]);
}


