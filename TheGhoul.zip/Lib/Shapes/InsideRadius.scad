//TODO add angle between surfaces
function InsideRadius(Radius,Centered=true)=
    let(
        /*
          for the sake of readability.
        */
        Steps=Segments(Radius)/4,
        Step=90/Steps,
        Center=Centered
        ?   [-Radius,-Radius,0]
        :   [0,0,0]
    )
    [ CropArray(AffineTransform(RotationMatrix(Vector=[0,0,Centered?180:0]),
        [
            Center,
            for (I=[0:Steps-1])
                [(1+cos(180+I*Step))*Radius,(1+sin(180+I*Step))*Radius,0]+Center,
            [Radius,0,0]+Center
        ]),2),
        [
            [ for (I=[0:Steps+1]) I ]
        ]
    ]
;
module InsideRadius(Radius,Centered=true){
    Foo=InsideRadius(Radius,Centered);
    polygon(Foo[0],Foo[1],2);
}


