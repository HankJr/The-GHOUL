/* TODO: centered waved - radius, arc...
 * This needs review.
    Size    : Height of the tooth.
    BaseW   : Width at the base.
    TopW    : Width at the top.
    OSx     : X-offset.
    OSy     : Y-offset.
*/
function Grooved(Size,BaseW,TopW,Shift=[0,0],Reps=1,Centered=true)=
    let(
        Step=BaseW+TopW,
        Center=Centered
        ?   0
        :   Step/2,
        Points=
            [
                [Shift.x, -0.5*(BaseW+TopW)+Shift.y+Center],
                [Shift.x,        -0.5*BaseW+Shift.y+Center],
                [Shift.x+Size,    -0.5*TopW+Shift.y+Center],
                [Shift.x+Size,     0.5*TopW+Shift.y+Center],
                [Shift.x,         0.5*BaseW+Shift.y+Center],
                [Shift.x,  0.5*(BaseW+TopW)+Shift.y+Center]
            ]
    )
    [
        [
            [0,Points[0][1]],
            for(Idex=[0:Step:Step*(Reps-1)])
                for(Jdex=[0:len(Points)-2])
                    Points[Jdex]+[0,Idex],
                Points[len(Points)-1]+[0,Step*(Reps-1)],
                [0,Points[0][1]+Step*Reps]
        ],
        [
            [
                for (I=[0:Reps*5+2]) I
            ]
        ]
    ]
;
module Grooved(Size,BaseW,TopW,Shift=[0,0],Reps=1,Centered=true){
    Foo=Grooved(Size,BaseW,TopW,Shift,Reps,Centered);
    polygon(Foo[0],Foo[1],4);
}
function Castellated(Size,Shift=[0,0],Reps=1,Centered=true)=
    Grooved(Size,Size,Size,Shift,Reps,Centered)
;
module Castellated(Size,Shift=[0,0],Reps=1,Centered=true){
    Foo=Grooved(Size,Size,Size,Shift,Reps,Centered);
    polygon(Foo[0],Foo[1],4);
}


