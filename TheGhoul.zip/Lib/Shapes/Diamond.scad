function Diamond(Width,Length,Centered=true)=
    let(
        _W=Width/2,
        _L=Length/2,
        Center=Centered
        ?   [0,0]
        :   [_W,_L],
        Points=
            [
                [_W,0]+Center,[0,_L]+Center,[-_W,0]+Center,[0,-_L]+Center
            ]
    )
    [
        Points,
        [
            [0,1,2,3]
        ]
    ]
;
module Diamond(Width,Length,Centered=true){
    Pol=Diamond(Width,Length,Centered);
    polygon(Pol[0],Pol[1],2);
}

