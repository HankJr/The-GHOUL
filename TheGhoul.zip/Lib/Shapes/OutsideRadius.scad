//TODO add angle between surfaces
function OutsideRadius(Radius)=
    let(
        /*
          for the sake of readability.
        */
        Steps=Segments(Radius)/4
    )
    [
        [
            [0,0],
            for (Step=[0:Steps-1])
                [cos(Step/Steps*90)*Radius,sin(Step/Steps*90)*Radius],
            [0,Radius]
        ],
        [
            [for (I=[0:Steps+1]) I]
        ]
    ]
;
module OutsideRadius(Radius){
    Foo=OutsideRadius(Radius);
    polygon(Foo[0],Foo[1],2);
}


