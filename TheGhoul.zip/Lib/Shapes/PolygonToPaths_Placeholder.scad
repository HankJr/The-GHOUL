/*
  Expand a complex polygon into an array of it's paths as arrays of vertices.
*/
