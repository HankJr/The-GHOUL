// A bit trivial but...
function RightTriangle(Width,Length)=
    [
        [
            [Width,0],[0,Length],[0,0]
        ],
        [[0,1,2]]
    ]
;
module RightTriangle(Width,Length){
    Foo=RightTriangle(Width,Length);
    polygon(Foo[0],Foo[1],2);
}


