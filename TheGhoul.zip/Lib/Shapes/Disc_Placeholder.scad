/*
  Circle, but in the way of Shapes, i.e., vertices and paths.
*/
