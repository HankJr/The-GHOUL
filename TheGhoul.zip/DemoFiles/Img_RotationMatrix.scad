/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

VertsA=[[0,0,0],[1,0,0],[0,1,0],[0,0,1],[0.5,0,1],[0,0.5,1]];
Faces=[[0,1,2],[0,1,4,3],[1,2,5,4],[2,0,3,5],[3,4,5]];

VertsB=AffineTransform(RotationMatrix([1,-1,0],45),VertsA);

polyhedron(VertsA,Faces);
color(RED)
polyhedron(VertsB,Faces);

color(GRN)
rotate(-45,[1,-1,0])
polyhedron(VertsA,Faces);
