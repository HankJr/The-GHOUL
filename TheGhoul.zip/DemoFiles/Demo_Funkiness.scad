// Whaddaya think-a-dis... It may be trivial, but it's funky...

/*
  Even though the cylinders are truncated by the 'difference()' operation, the last drawn cylinder 'overshadows' the first... When the '$fn' of the cylinders are not identical, the 'interference' pattern of the truncated part still shows up...
*/

/* Change either fn1 or fn2 to another value, makes no difference what, they just need to be different values, and observe... */
/* Animated demo. */
//fn1=min(20+100*$t,100);
/* Static demo. */
fn1=200;
fn2=300;

// Centered green cylinder with bottom half 'cut off'.
color("green")
difference(){
    cylinder(r=10,h=10,center=true,$fn=fn2);
    translate([0,0,-5])
    cube([25,25,10],center=true);
}

// Centered red cylinder with the top half 'cut off'.
color("red")
difference(){
cylinder(r=10,h=10,center=true,$fn=fn1);
    translate([0,0,5])
    cube([25,25,10],center=true);
}
