/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

// Some text
color(ORD)
translate([-2,20,0])
SimpleText("TheGHOUL writes Braille!",6.5,Thickness=0.1,Center=false,Font="Noto Mono",Spacing=1);

// The above text in Braille
color(DSG)
translate([3,3,0])
BrailleText("TheGHOUL writes Braille!");
