/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

/*$vpt=[8,8,0];
$vpr=[45,0,45];
$vpd=30;*/

Grooved(2,2,1,[0,0],Reps=1,Centered=true);

translate([0,4,0])
Grooved(2,2,1,[1,0],Reps=1,Centered=true);

translate([5,0,0])
Grooved(2,2,1,[1,0],Reps=4,Centered=true);

translate([10,0,0])
Grooved(2,1,2,[1,0],Reps=4,Centered=true);

color("silver")
translate([14,10.5,0])
rotate([0,0,180])
Grooved(2,1,2,[1,0],Reps=4,Centered=true);

