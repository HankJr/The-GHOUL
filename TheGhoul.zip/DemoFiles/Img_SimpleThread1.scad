/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

*Tumble([0,20*sin(360*$t),40*sin(360*$t)],1)
    difference(){
        translate([-20,-20,0])
        cube([40,40,30]);
        rotate([0,0,0])
        SimpleThreadedHole(20,20,4,CounterSink=false);
        color("red")
        translate([-28,-28,-3])
        cube([30,30,35]);
    }

translate([0,20,0])rotate([0,0,180])SimpleThreadedRod(35,20,20,4,StartTaper=false);

translate([0,50,0])SimpleThreadedRod(60,20,20,4,StartTaper=true,Stud=true);

translate([0,20,45])
difference(){
    SimpleThreadedRod(20,20,20,2.5,StartTaper=true,Stud=true);
    color(DSG) // Hex hole for Allen key.
    translate([0,0,16])
    cylinder(r=4.5,h=5,$fn=6);
}

translate([0,-15,0])SimpleBolt(Size=32,Head=12,Sides=6,Length=60,Threads=40,Diameter=20,Pitch=2.5);

translate([0,0,-20])SimpleNut(Size=60,Height=10,Sides=12,Diameter=40,Pitch=3,InChamfer=0.3);
