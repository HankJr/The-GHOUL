/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$vpt=[0,0,0];
$vpr=[60,0,360*$t];

/* Pound coin inscriptions. */

/* The red dragon leads the way. */
SimpleBarrelText("Y DDRAIG GOCH DDYRY CYCHWYN",1,10,Helix=0,Thickness=0.3,Center=true,Font="Noto Mono",Spacing=1,Raise=0,Vert=false);

/* An ornament and a safeguard. */
rotate([0,0,180])
SimpleBarrelText("DECUS ET TUTAMEN",1,10,Helix=0,Thickness=0.3,Center=true,Font="Noto Mono",Spacing=1,Raise=0,Vert=false);

/* No one assaults me with impunity. */
rotate([0,0,110])
translate([0,0,0])
SimpleBarrelText("NEMO ME IMPUNE LACESSIT",1,10,Helix=30,Thickness=0.3,Center=true,Font="Noto Mono",Spacing=1.3,Raise=0,Vert=true);

/* For so much, what shall we repay? */
rotate([0,0,-90])
translate([0,0,0])
SimpleBarrelText("PRO TANTO QUID RETRIBUAMUS",1,10,Helix=-30,Thickness=0.3,Center=true,Font="Noto Mono",Spacing=1,Raise=0,Vert=false);

color(DSG,0.3)
cylinder(r=10,h=21,center=true);
