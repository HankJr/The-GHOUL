/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca

  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what is happening.
*/

include<TheGHOUL/Config.scad>

color(CPR){
translate([0,4.5,0])
SimpleText("[[1,0,0],",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([1,3,0])
SimpleText("[0,1,0],",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([1,1.5,0])
SimpleText("[0,0,1]]",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
}
