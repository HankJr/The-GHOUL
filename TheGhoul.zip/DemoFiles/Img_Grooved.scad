/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca

  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what is happening.
*/


include<TheGHOUL/Config.scad>

/*$vpt=[8,8,0];
$vpr=[45,0,45];
$vpd=30;*/

Grooved(2,2,1,[1,0],Reps=1,Centered=true);

T=0.06;

translate([0,0,0.5])
Dimension([1,-1,0],[1,1,0],Type="V",Text="BaseW",TSize=0.8,Gap=0.5,TMove=[0,0.2,0],Spacing=2,Extension=0.5,Direction="R",Location="A",Thickness=T,Marks="C",MSize=0.3,TSpacing=1);
Dimension([3,-0.5,0],[3,0.5,0],Type="V",Text="TopW",TSize=0.8,Gap=0.5,TMove=[0,0.2,0],Spacing=2,Extension=0.5,Direction="R",Location="B",Thickness=T,Marks="C",MSize=0.3,TSpacing=1);
Dimension([1,1,0],[3,0.5,0],Type="H",Text="Size",TSize=0.8,Gap=0.5,TMove=[0,0.2,0],Spacing=5,Extension=0.5,Direction="R",Location="A",Thickness=T,Marks="C",MSize=0.3,TSpacing=1);
Dimension([0,-1.5,0],[1,-1.5,0],Type="H",Text="Shift",TSize=0.8,Gap=0.5,TMove=[0,0.2,0],Spacing=2,Extension=0.5,Direction="R",Location="B",Thickness=T,Marks="C",MSize=0.3,TSpacing=1);





