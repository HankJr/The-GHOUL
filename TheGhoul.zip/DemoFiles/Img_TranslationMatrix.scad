/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

VertsA=[[0,0,0],[1,0,0],[0,1,0],[0,0,1],[0.5,0,1],[0,0.5,1]];
Faces=[[0,1,2],[0,1,4,3],[1,2,5,4],[2,0,3,5],[3,4,5]];

VertsB=AffineTranslate([1,1,0.5],VertsA);
echo(VertsB);
color(RED)
polyhedron(VertsB,Faces);
color(OSG,0.7)
polyhedron(VertsA,Faces);
