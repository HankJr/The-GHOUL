/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$AnimSegs=10;

/*
  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what happens here.
*/

Animate([0,10,10]){
    Tumble([720,540,720],$AnFrac)
    color([1-$AnFlash*0.2,0.5,$AnFlash*0.7],0.7)
    ChamferedCube(Width=1,Length=1,Height=2,Chamfer=0.2);
}
