/* You gotta get The GHOUL. */
include<TheGHOUL/Config.scad>

$AnimSegs=10;

// Uncomment only ONE of the next two lines.

//$vpt=Animator([[0,[-70,0,0]],[2,[-1,0,0]],[8,[-1,0,0]],[10,[-70,0,0]]],Shift=0); $vpr=Animator([[0,[15,0,45]],[2,[0,15,45]],[5,[-15,0,45]],[8,[0,-15,45]],[10,[15,0,45]]],Shift=0); $vpd=Animator([[0,400],[2,10],[8,10],[10,400]],Shift=0); One();

$vpt=([-1,0,0]); $vpd=20; One();

/*
  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what is happening.
*/

module One(){
    translate([-10,0,0])color(DRD)
    Arc(0,360,10,0.1,Pattern=[1,0.3,0.3,0.3]);
    translate([-10,0,-0.205])color(RED)
    linear_extrude(0.2)
    InvoluteGear(2,10);

    translate([-20,0,-0.2])color(DGN)
    Arc(0,360,20,0.1,Pattern=[1,0.3,0.3,0.3]);
    translate([-20,0,-0.4])color(GRN)
    linear_extrude(0.2)
    InvoluteGear(2,20);

    translate([-140,0,-0.4])color(DBL)
    Arc(0,360,140,0.1,Pattern=[1,0.3,0.3,0.3]);
    translate([-140,0,-0.6])color(BLU)
    linear_extrude(0.2)
    InvoluteGear(2,140);
}

//Two();
module Two(){
    TT=ceil(Cycle(20,140));

    rotate([-25,0,0]){
    translate([-TT,0,0])color(DRD)
    Arc(0,360,TT,0.1,Pattern=[1,0.3,0.3,0.3]);
    translate([-TT,0,-0.205])color(RED)
    linear_extrude(0.2)
    InvoluteGear(2,TT);}

    color(DSG)
    translate([-2,0,1])
    rotate([15,15,0])
    SimpleText(str(TT),1,Thickness=0.1,Center=true,Font="Noto Mono",Spacing=1);
}
