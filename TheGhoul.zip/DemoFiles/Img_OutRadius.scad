/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$vpt=[8,0,0];$vpr=[20,0,90];$vpd=25;

translate([0,0,3])
color("gold")
SimpleCircleText("The hole you have.",0.5,7,Thickness=0.2,Center=true,Font="Noto Mono",Spacing=1);

translate([0,0,3])
color("red")
SimpleCircleText("The hole you wanted.",0.5,8,Thickness=0.2,Center=true,Font="Noto Mono",Spacing=1);

translate([0,0,3])
color("purple")
SimpleCircleText("What OutRadius() gives you.",0.5,9,Thickness=0.2,Center=true,Font="Noto Mono",Spacing=1);

// Text background circle
color(DSG,0.2)
translate([0,0,1.1])
circle(r=9.5,$fn=360);

// Normal circle
color(OSG)
translate([0,0,1.001])
circle(r=10,$fn=12);

// Circle with high $fn value to represent a 'true circle'
color(RED)
circle(r=10,$fn=360);

// OCFudged circle.
color(PRP)
translate([0,0,-1.001])
circle(r=OutRadius(10),$fn=12);
/* OutRadius() is in the same namespace as the $fn declaration (the parentheses of the circle() call); it therefore doesn't need to explicitly be told what $fn is. */

// Background circle
color(SVR,0.2)
translate([0,0,-2.002])
circle(r=20);

