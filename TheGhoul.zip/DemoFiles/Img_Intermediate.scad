/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

    //$t=0.4; // Test.

    echo(Intermediate([[0,0],[10,10]],[[5,10],[30,20]],0.4));
    echo(Intermediate([10,10],[30,20],0.4));
    echo(Intermediate(10,20,0.4));

    Start=[[0,0,0],[4,4,0],[3,8,0]];
    End=[[0,4,10],[2,8,8],[5,10,6]];

    ShowCurve(Start,0.2,Connect=true);
    ShowCurve(End,0.2,Connect=true);

    color(Intermediate(RED,BLU,$t))
    ShowCurve(Intermediate(Start,End,$t),0.2,Connect=true);

