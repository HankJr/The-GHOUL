/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

/* The old wheel turns.. */
color(RED,0.8)
SimpleCircleText("Mae'r olwyn yn troi",2,10,Thickness=0.5,Center=false,CW=false,Font="Noto Mono",Spacing=1);
color("green",0.4)
translate([0,0,-1.7])
cylinder(r=12,h=2);
