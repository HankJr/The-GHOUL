/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

VPT=[0,[3,3,0],[0,0,0],20];
$vpt=VPT[1];
$vpr=VPT[2];
$vpd=VPT[3];

GraphPaper(Major=1,Minor=1/4,Size=[[0,0],[6,6]],LineFactor=170,Color=GPG,Alpha=0.5);
color(BLK)BallCylinderBetween([0,4],[2.75,4],0.02,"Both");
color(BLK)BallCylinderBetween([2.75,4],[2.75,0],0.02,"Both");
color(BLU)BallCylinderBetween([0,1],[0,5],0.05,"Both");
color(GRN)BallCylinderBetween([2,0],[5,0],0.05,"Both");
color(RED)BallCylinderBetween([2,5],[5,1],0.05,"Both");
translate([-0.5,1])
text("Y1",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
translate([-0.5,5])
text("Y0",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
color(BLK)
translate([-0.5,4])
text("?",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
translate([2,-0.5])
text("X0",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
color(BLK)
translate([2.75,-0.5])
text("X",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
translate([5,-0.5])
text("X1",size=0.3,halign="center",valign="center",font = "Liberation Sans:style=Bold");
