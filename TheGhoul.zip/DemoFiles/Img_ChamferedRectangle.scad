/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca

  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what happens here.
*/

include<TheGHOUL/Config.scad>

$vpt=[0,0,0];
$vpr=[45,0,45];
$vpd=30;

ChamferedRectangle(8,4,1,Centered=true);
Dimension([3,-2,0],[4,-1,0],Type="H",Text="Chamfer",TSize=1,TSpacing=1,TMove=[1,0,0],Decimals=2,Spacing=-2,Extension=-0.5,Gap=0.25,Direction="R",Location="A",Thickness=0.1,Marks="C",MSize=0.3,Outside=false);
