/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>


color([ StringTee(3,7,0,255)/255, 255/255, StringTee(3,7,255,0)/255 ])
rotate([StringTee(0,3,0,90),StringTee(3,7,0,90),StringTee(7,10,0,90)])
cube([20,StringTee(0,3,1,20)-StringTee(7,10,0,19),20],center=true);

color(CPR)
ScreenPosition(Location=[-3,5,0])
SimpleText(str("$t= ",$t),2,Spacing=0.75);
