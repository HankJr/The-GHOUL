include<TheGHOUL/Config.scad>
$AnimSegs=10;
$Verbose=true;
$Debug=true;
$vpt=[1,1,0];$vpr=[60,0,30];$vpd=23;
MV=3.5;

TPA=[
    [ // TPS(s) - Partial curves, multiples are 'chained'.
        [ // TP(s)
            [[0,0,0],[MV,70,60]]
        ],[]
    ]
];

ShowTPA(TPA,Curves=[]);

Dimension([MV*cos(20)*cos(60),MV*cos(20)*cos(30),MV*sin(20)],[0,0,0],Type="A",Text="  MV",TSize=0.4,TSpacing=1,TMove=[0,0,0],Decimals=0,Spacing=2,Extension=0.5,Gap=0.25,Direction="R",Location="B",Thickness=0.05,Marks="A",MSize=0.3,Outside=true,Rotation=0);

color(RED)
ArrowArc(0,60,MV*cos(20),Thickness=0.1,Points=[0.2,0.2,1],Center=[0,0,0]);

color(DRD)
rotate([0,-90,-30])
ArrowArc(0,70,MV,Thickness=0.1,Points=[0.2,0.2,1],Center=[0,0,0]);

rotate([0,-90,-30])
color(RED,0.3)
linear_extrude(0.01)
polygon(concat([[0,0]],Arc(0,70,MV)));

color(RED,0.3)
linear_extrude(0.01)
polygon(concat([[0,0]],Arc(0,60,MV*cos(20))));

rotate([90,0,60])
color(DSG,0.2)
linear_extrude(0.01)
polygon([[0,0],[MV*cos(20),0],[MV*cos(20),MV*sin(20)]]);

ScreenText(Text="Inclination",Location=[5,6,0],Rotation=[5,5,0],Size=0.5,Color=DSG,_SizeCompensation=40);
ScreenText(Text="Azimuth",Location=[7,-1,0],Rotation=[5,5,0],Size=0.5,Color=DSG,_SizeCompensation=40);
ScreenText(Text="Vertex",Location=[-5,0,0],Rotation=[5,5,0],Size=0.5,Color=DSG,_SizeCompensation=40);

