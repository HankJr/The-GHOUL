include<TheGHOUL/Config.scad>

        Vertex=[0,0];

        Curve=Trochoid(20,10,20);
        ShowCurve(Curve,0.2);
        Index=TangentPoint(Vertex,Curve,Direction=1);
        color($t<(2/3)?GRN:RED)
        BallCylinderBetween(Vertex,
            Curve[min(1,3/2*$t)*Index]
            ,Radius=0.2,Ends="Both");
