include<TheGHOUL/Config.scad>

/*
  View in animation window, with Steps=100.
*/

$AnimSegs=10;
$vpt=[0,0,0];$vpr=[40,0,14];$vpd=35;
$fn=100;

translate([0,0,-1])
color(GRY,0.3)
circle(50);
ShowTrochoidK(2,-2,1,Kolor=DSG,Fade=true,CFN=6);
ShowTrochoidK(2,2,1,Kolor=CPR,Fade=true,CFN=6);
