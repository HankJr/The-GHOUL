include<TheGHOUL/Config.scad>


        /*
            I can't exactly remeber why I wrote this, but I'm resonably sure I'll miss it when I delete it, so... Here it is.
        */


        $ff=0;

        R=10;
        r=R/2;
        h=5;

        A=r;
        B=R+h;
        C=R+r;

        Angle=acos((Pow2(A)+Pow2(C)-Pow2(B))/(2*A*C))*r/R;

        T=Last(Trochoid(R,r,r,Angle));

        echo("Angle = ",Angle)
        echo("T = ",T)

        ShowCurve(Circle(R),0.05,Closed=false);
        ShowCurve(Arc(0,Angle,R+h),0.05,Closed=false);
        color(BLU)
        ShowCurve(
            Trochoid(R,r,r,Angle)
        ,0.05);
