/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

TRNS=2.1;

    translate([0,0,4*TRNS])
    rotate([0,0,360*TRNS])
    difference(){

        color(CPR)
        union(){

        SimpleThread(Turns=4,Diameter=20,Pitch=4,Internal=false,Angle=60,Root=1/4,Crest=1/8,LeftHanded=false,BeginHigbee=0.25,EndHigbee=0.25,HigbeePower=0.3,Correction=0);

        cylinder(r=7.54626, h=20);

        }

        color(CPR)
        translate([-100,-100,-1])
        cube([200,100,100]);

    }


    difference(){

        color(DSG)
        union(){

            rotate([0,0,180])
            SimpleThread(Turns=4,Diameter=20,Pitch=4,Internal=true,Angle=60,Root=1/4,Crest=1/8,LeftHanded=false,BeginHigbee=0.25,EndHigbee=0.25,HigbeePower=0.3,Correction=0);

            difference(){
                translate([-11,0,HalfCut])
                cube([22,11,20-Cut]);
                cylinder(r=10.1443, h=20);
            }

        }

        color(DSG)
        translate([-100,-100.1,-1])
        cube([200,100,100]);

    }
