/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$AnimSegs=10;

VPT = [0, [5, 3, 4], [70, 0, 160], 70];
$vpt=VPT[1];
$vpr=VPT[2];
$vpd=VPT[3];

Animate([0,0,2,6])
ToonPlane(Alpha=$AnFrac);

Animate([1,1,2,8])
color(DSG,$AnFrac)
Arrow(Vector=[10,10,0],Base=[4,4,0],Points=[0,0.4,1],Thickness=0.5);

Animate([1,1,2,6])
ScreenText(Text="Position([1,1,0],[10,10,0],30)",Location=[0,6.5,5],Rotation=[5,5,0],Size=0.8,Color=DSG,_SizeCompensation=60);

Animate([2,2,4,6])
Position(Vector=[1,1,0],Base=[10,10,0],Roll=-30,Alignment="Z")
ToonPlane(Alpha=$AnFrac);

Animate([6,6,7,10])
ToonPlane("red","gold","green",Alpha=$AnFrac);

Animate([6,6,8,10])
ScreenText(Text="Position([1,1,0],[10,10,0],30,\"X\")",Location=[0,6.5,5],Rotation=[5,5,0],Size=0.8,Color="red",_SizeCompensation=60);

Animate([7,7,9,10])
Position(Vector=[1,1,0],Base=[10,10,0],Roll=-30,Alignment="X")
ToonPlane("red","gold","green",Alpha=$AnFrac);
