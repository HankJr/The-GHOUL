/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

/*
  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what is happening.
*/

$vpt=[0,0,-5];
$vpr=[45,0,45];
$vpd=50;

GTTooth(Teeth=0,Type="GT3-2",Clearance=0);
translate([-4,0,0])
GTTooth(Teeth=24,Type="GT3-2",Clearance=0);

translate([0,0,-5])
difference(){
color(OSG)
GTPulley(Teeth=24,Width=6,Type="GT3-2");
color(DSG)
translate([0,0,6])
ChamferedCylinder(5,10,1,ChamferAngle=45);

}
