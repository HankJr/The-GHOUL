/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$vpt=[2.5,1,0];
$vpr=[45,0,45];
$vpd=30;

//color("silver")

NGon(Sides=5,Radius=3,Centered=true);
translate([0,0,0.5])
Dimension([-2.42705,0,0],[0,0,0],Type="H",Text="X-Offset",TSize=0.8,TMove=[0.5,0.2,0],Spacing=5,Extension=0.5,Gap=0,Direction="R",Location="B",Thickness=0.05,Marks="C",MSize=0.3,TSpacing=1);
translate([0,0,0.5])
Dimension([0,0,0],[3*cos(72),3*sin(72),0],Type="V",Text="Y-Offset",TSize=0.8,TMove=[0.5,0.2,0],Spacing=4.5,Extension=0.5,Gap=0,Direction="R",Location="B",Thickness=0.05,Marks="C",MSize=0.3,TSpacing=1);
