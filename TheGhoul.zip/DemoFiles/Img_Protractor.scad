/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

$AnimSegs=10;

$vpt=[9.78253, 2.17848, 0];$vpr=[0,0,0];$vpd=min(max(100*(1-$t),10),90);

ScreenText(Text="12.5 degrees",Location=[5,3,5],Rotation=[5,5,12.5],Size=0.6,Color=DSG,_SizeCompensation=40);

Animate([0,0,3,10])
Protractor(Radius=10+(1-$AnFrac)*40,Scales=[0.5,1,10,30,90],Center=false);

Animate([0,0,3,10])
ALine(12.5,0.1+(1-$AnFrac)*0.5);

