/* You gotta get The GHOUL. */
include<TheGHOUL/Config.scad>

//BezierCurve([[[0,0,0],[7,2,0],[10,9,0],[6,15,0],[0,8,0]]],Resolution=50,Start=0,End=1,Radius=0.2,Points=-0.15,CurveColor=RED,PointsColor=BLU);

CPS=[[0,0],[0.551915,0],[1,1-0.551915],[1,1]]*20;
ShowDeCasteljau(CPS,0.7,30);
for (Point=CPS)
    color(GRN)
    translate(PadTuple(Point))
    sphere(r=0.55);
