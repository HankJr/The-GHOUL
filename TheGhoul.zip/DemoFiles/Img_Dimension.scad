/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca

  Nothing that happens here merits explanation. Just read the documentation and comments in the actual routines and functions that are used here if something doesn't make sense or it's not clear to you what happens here.
*/

include<TheGHOUL/Config.scad>

P1=[6,4,0];
P2=[10,6,0];
T=0.08;

BallCylinderBetween(P1,P2,Radius=0.2);
Dimension(P1,P2,Type="A",Text="",TSize=1,TSpacing=1,TMove=[0,0,0],Decimals=2,Spacing=2,Extension=0.5,Gap=0.5,Direction="C",Location="A",Thickness=T,Marks="C",MSize=0.5,Outside=false);
Dimension(P1,P2,Type="H",Text="",TSize=1,TSpacing=1,TMove=[0,0,0],Decimals=2,Spacing=2,Extension=0.5,Gap=0.5,Direction="L",Location="B",Thickness=T,Marks="A",MSize=0.5,Outside=false);
Dimension(P1,P2,Type="V",Text="",TSize=1,TSpacing=1,TMove=[0,0,0],Decimals=2,Spacing=2,Extension=0.5,Gap=0.5,Direction="R",Location="B",Thickness=T,Marks="A",MSize=0.5,Outside=true);
