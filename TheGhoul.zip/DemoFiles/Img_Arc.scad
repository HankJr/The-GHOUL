/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>


        $fa=36;
        $fc=16;
        echo(Segments(3/2));

        Circle(10,1,Pattern=[5,2]);

        Arc(0,170,15,1,Pattern=[3,2,2,2,3]);

        ShowCurve(
            Circle(5)
        ,0.5,0.6,true,true);

        circle(3);
