/*
  This file belongs in

  <TheGHOUL/DemoFiles/>

  Hank J. van Leuvensteijn Jr. 2021
  theghoul@hankjr.ca
*/

include<TheGHOUL/Config.scad>

color(CPR){
translate([0,4.5,0])
SimpleText("[[00,  ,  ],",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([1,3,0])
SimpleText("[  ,11,  ],",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([1,1.5,0])
SimpleText("[  ,  ,22]]",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
}

$T=(1+cos($t*360))/2;

A=2*abs(-0.5+$T)*0.8+0.2;

color(RED,A){
translate([5-3*$T,4.5-1.5*$T,0])
SimpleText("01",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([2+3*$T,3+1.5*$T,0])
SimpleText("10",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
}

color(OSG,A){
translate([8-6*$T,4.5-3*$T,0])
SimpleText("02",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([2+6*$T,1.5+3*$T,0])
SimpleText("20",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
}

color(GRN,A){
translate([8-3*$T,3-1.5*$T,0])
SimpleText("12",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
translate([5+3*$T,1.5+1.5*$T,0])
SimpleText("21",1,Thickness=0.3,Center=false,Font="Noto Mono",Spacing=1);
}
