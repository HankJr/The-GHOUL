include<TheGHOUL/Config.scad>


        color(DSG,0.2)
        translate([0,0,-2])
        circle(200);
        color(CPR)
        Snail(OD=80,Steps=12,Drop=2,ID=10,Thickness=5);
