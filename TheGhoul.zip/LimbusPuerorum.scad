/*
  Limbus Puerorum

  Here live the routines that haven't made it into the library proper yet, for whatever reason.

  ****
    This file is include<>d by Config.scad, so routines here are available throughout the library.
  ****

  Ideally NOTHING should live here, but clearly, things are not ideal.
*/


/* Should these be promoted? */
function NegOneIfOdd(I)= I%2==1?-1:1;
function ZeroIfOdd(I)= I%2==1?0:1;

/*
    UCS - a system of 3 independent unit-vectors like [[1,0,0],[0,1,0],[0,0,1]] (but that would be the world CS).
    Vector - a vector in UCS coordinates.

    * NOTE: In case you missed it: the UCS contains UNIT-vectors!

    Returns 'Vector' in world coordinates.
*/
function WCSVector(UCS,Vector) =
    UCS.x*Vector.x+UCS.y*Vector.y+UCS.z*Vector.z
;

function Z0(Vector)=
    [Vector.x,Vector.y,0]
;

// =============================================================================

/*TODO

Write these functions:
    ArrayPush()
    ArrayPop()
    ArrayShift()
    ArrayUnShift()
*/
